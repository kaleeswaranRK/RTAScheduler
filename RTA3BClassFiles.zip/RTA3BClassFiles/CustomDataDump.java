
//javac -classpath E:\CustomReporting\scheduler\libs\mssql-jdbc-8.4.1.jre8.jar;E:\CustomReporting\scheduler\libs\postgresql-42.2.18.jar;. CustomDataDump.java

//java -classpath E:\CustomReporting\scheduler\libs\mssql-jdbc-8.4.1.jre8.jar;E:\CustomReporting\scheduler\libs\postgresql-42.2.18.jar;. CustomDataDump

import java.sql.*;
import java.util.Date;
import java.util.*;
import java.text.*;
import java.io.*;

public class CustomDataDump {

	static String START_TIME = "2021-01-06 00:00:00.000";
	static String END_TIME = "2021-01-06 15:00:00.000";

	public static void cleanupTables(Connection con, String tableName) throws Exception {

		Statement stmt = con.createStatement();
		System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "Cleanup " + tableName);
		if (tableName != null && tableName != "") {
			stmt.executeUpdate("DELETE FROM " + tableName);
			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "Cleanup Completed " + tableName);
		} else {
			// stmt.executeUpdate("DELETE FROM DIM_ROUTING_SERVICES");
			// stmt.executeUpdate("DELETE FROM DIM_AGENTS");
			// stmt.executeUpdate("DELETE FROM DIM_NOT_READY_REASON_CODES");
		}
	}

	//2b.dump CallBack data from CBA database
	public static void loadCallBack(Connection con, Connection mssqlcon) throws Exception {
		try {

			Statement stmt = con.createStatement();

			String sql = "SELECT id, TO_CHAR(userrequesttime, 'YYYY-MM-DD HH24:MI:SS.MS') as userrequesttime, currentstatus, retrynumber, busyretrynumber, noanswerretrynumber,phonenumber, "
					+ "callbackconfigid, TO_CHAR(scheduleddatetime, 'YYYY-MM-DD HH24:MI:SS.MS') as scheduleddatetime, TO_CHAR(nextretrytime, 'YYYY-MM-DD HH24:MI:SS.MS') as nextretrytime, TO_CHAR(launchtime, 'YYYY-MM-DD HH24:MI:SS.MS') as launchtime, currentstatustime,callinfoid, callertimediff, "
					+ "requesteddatetime, channeltype, sessionid, vdn, guid, ewtinseconds, siteid, deliverysiteid, agentqueue,"
					+ "expselectionattrid, oceanametricsid FROM callback "
					+ "WHERE userrequesttime >= TO_TIMESTAMP(" + "'" + START_TIME + "'," + "'"
					+ "YYYY-MM-DD HH24:MI:SS.MS" + "')" + "AND userrequesttime < TO_TIMESTAMP(" + "'" + END_TIME + "',"
					+ "'" + "YYYY-MM-DD HH24:MI:SS.MS" + "')";

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadCallBack: Select Query: " + sql);

			ResultSet rs = stmt.executeQuery(sql);

			String insertQuery = "INSERT INTO dbo.callback (id, userrequesttime, currentstatus, retrynumber, busyretrynumber, noanswerretrynumber, phonenumber, callbackconfigid, scheduleddatetime, nextretrytime, launchtime, currentstatustime, callinfoid, callertimediff, requesteddatetime, channeltype, sessionid, vdn, guid, ewtinseconds, siteid, deliverysiteid, agentqueue, expselectionattrid, oceanametricsid) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadCallBack => insertQuery: " + insertQuery);
			PreparedStatement pstmt = mssqlcon.prepareStatement(insertQuery);
			while (rs.next()) {
				pstmt.setInt(1, rs.getInt("id"));
				pstmt.setString(2, rs.getString("userrequesttime"));
				pstmt.setInt(3, rs.getInt("currentstatus"));
				pstmt.setInt(4, rs.getInt("retrynumber"));
				pstmt.setInt(5, rs.getInt("busyretrynumber"));
				pstmt.setInt(6, rs.getInt("noanswerretrynumber"));
				pstmt.setString(7, rs.getString("phonenumber"));
				pstmt.setInt(8, rs.getInt("callbackconfigid"));
				pstmt.setString(9, rs.getString("scheduleddatetime"));
				pstmt.setString(10, rs.getString("nextretrytime"));
				pstmt.setString(11, rs.getString("launchtime"));
				pstmt.setString(12, rs.getString("currentstatustime"));
				pstmt.setInt(13, rs.getInt("callinfoid"));
				pstmt.setInt(14, rs.getInt("callertimediff"));
				pstmt.setString(15, rs.getString("requesteddatetime"));
				pstmt.setInt(16, rs.getInt("channeltype"));
				pstmt.setString(17, rs.getString("sessionid"));
				pstmt.setString(18, rs.getString("vdn"));
				pstmt.setString(19, rs.getString("guid"));
				pstmt.setInt(20, rs.getInt("ewtinseconds"));
				pstmt.setInt(21, rs.getInt("siteid"));
				pstmt.setInt(22, rs.getInt("deliverysiteid"));
				pstmt.setString(23, rs.getString("agentqueue"));
				pstmt.setInt(24, rs.getInt("expselectionattrid"));
				pstmt.setInt(25, rs.getInt("oceanametricsid"));
				// insert the data
				pstmt.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//2b.dump CallBackSummary from CBA database
	public static void loadCallBackSummary(Connection con, Connection mssqlcon) throws Exception {
		try {

			Statement stmt = con.createStatement();

			String sql = "SELECT id, TO_CHAR(dateinterval, 'YYYY-MM-DD HH24:MI:SS.MS') as dateinterval,TO_CHAR(hourinterval, 'YYYY-MM-DD HH24:MI:SS.MS') as hourinterval, incomingcalls, callsofferedacallback, immediatecallbacks, scheduledcallbacks,"
					+ " deliveredcallbacks, terminatedcallbacks, maxretriesreachedcallbacks, canceledcallbacks, outstandingcallbacks,"
					+ " callbackconfigid, canceledbycustomer, requesttype, canceledbyapplication FROM callbacksummary"
					+ " WHERE hourinterval >= TO_TIMESTAMP(" + "'" + START_TIME + "'," + "'"
					+ "YYYY-MM-DD HH24:MI:SS.MS" + "')" + "AND hourinterval < TO_TIMESTAMP(" + "'" + END_TIME + "',"
					+ "'" + "YYYY-MM-DD HH24:MI:SS.MS" + "')";

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadCallBackSummary: Select Query: " + sql);

			ResultSet rs = stmt.executeQuery(sql);

			String insertQuery = "INSERT INTO dbo.CallBackSummary (id, dateinterval, hourinterval, incomingcalls, callsofferedacallback, immediatecallbacks, "
					+ "scheduledcallbacks, deliveredcallbacks, terminatedcallbacks, maxretriesreachedcallbacks, canceledcallbacks, outstandingcallbacks,"
					+ " callbackconfigid, canceledbycustomer, requesttype, canceledbyapplication)"
					+ "	VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : "+ "loadCallBackSummary => insertQuery: " + insertQuery);
			PreparedStatement pstmt = mssqlcon.prepareStatement(insertQuery);
			while (rs.next()) {
				pstmt.setInt(1, rs.getInt("id"));
				pstmt.setString(2, rs.getString("dateinterval"));
				pstmt.setString(3, rs.getString("hourinterval"));
				pstmt.setInt(4, rs.getInt("incomingcalls"));
				pstmt.setInt(5, rs.getInt("callsofferedacallback"));
				pstmt.setInt(6, rs.getInt("immediatecallbacks"));
				pstmt.setInt(7, rs.getInt("scheduledcallbacks"));
				pstmt.setInt(8, rs.getInt("deliveredcallbacks"));
				pstmt.setInt(9, rs.getInt("terminatedcallbacks"));
				pstmt.setInt(10, rs.getInt("maxretriesreachedcallbacks"));
				pstmt.setInt(11, rs.getInt("canceledcallbacks"));
				pstmt.setInt(12, rs.getInt("outstandingcallbacks"));
				pstmt.setInt(13, rs.getInt("callbackconfigid"));
				pstmt.setInt(14, rs.getInt("canceledbycustomer"));
				pstmt.setInt(15, rs.getInt("requesttype"));
				pstmt.setInt(16, rs.getInt("canceledbyapplication"));
				// insert the data
				pstmt.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void loadCDR_CONTACTS(Connection con, Connection mssqlcon) throws Exception {

		// Statement delete_stmt=mssqlcon.createStatement();
		// System.out.println("\n"+new Timestamp(new Date().getTime()) + " : "
		// +"Deleting CDR_CONTACTS records on the same interval delete_stmt : " +
		// "DELETE FROM CDR_CONTACTS WHERE ORIGINATED_TIMESTAMP >= '"+START_TIME+"' and
		// ORIGINATED_TIMESTAMP < '"+END_TIME+"'");
		// delete_stmt.executeUpdate("DELETE FROM CDR_CONTACTS WHERE
		// ORIGINATED_TIMESTAMP >= '"+START_TIME+"' and ORIGINATED_TIMESTAMP <
		// '"+END_TIME+"'");

		Statement stmt = con.createStatement();

		String sql = "SELECT ROUTING_POINT_SK, ROUTING_SERVICE_SK, ENGAGEMENT_SK, CONTACT_SK, ENGAGEMENT_ID, CONTACT_ID, CUSTOMER_ID, TO_CHAR(ORIGINATED_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS ORIGINATED_TIMESTAMP, TO_CHAR(END_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS END_TIMESTAMP, RING_TIME_DURATION, HANDLING_TIME_DURATION, HOLD_DURATION, ACTIVE_TIME_DURATION, ABANDONED_INDICATOR, INITIAL_DISPOSITION, FINAL_DISPOSITION, CONTACT_DURATION, CALLING_PARTY, IS_EXTERNAL, INCOMPLETE, SEGMENT_TYPE, TRANSFERRED_INDICATOR, CONSULT_INDICATOR, CONFERENCE_INDICATOR, TRANSFERRED_COUNT, CONSULT_COUNT, CONFERENCE_COUNT, DESTINATION_PARTY, PERSONAL_CONTACT_INDICATOR, WAIT_TIME_INDICATOR, WAIT_TIME, TREATMENT_INDICATOR, COVERAGE_INDICATOR, ROUTING_DURATION, DEFERRED_INDICATOR, AGENT_DISCONNECT_FIRST, LAST_ROUTING_SERVICE_SK, EMAIL_FORWARD_INDICATOR, TO_CHAR(CUSTOMER_CONTACT_END_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS CUSTOMER_CONTACT_END_TIMESTAMP, AUTO_REDACTED, CONVERSATION_THREAD_ID, MESSAGE_SOURCE_ID, TO_CHAR(LAST_CHANGED, 'YYYY-MM-DD HH24:MI:SS.MS') AS LAST_CHANGED, REPLY_INDICATOR,  SENT_FOR_APPROVAL_INDICATOR, APPROVAL_HANDLING_DURATION, REWORK_HANDLING_DURATION, INITIAL_WAIT_TIME_INDICATOR, INITIAL_WAIT_TIME from FACT.cdr_contacts WHERE ORIGINATED_TIMESTAMP >= TO_TIMESTAMP('"
				+ START_TIME + "', 'YYYY-MM-DD HH24:MI:SS.MS') AND ORIGINATED_TIMESTAMP < TO_TIMESTAMP('" + END_TIME
				+ "', 'YYYY-MM-DD HH24:MI:SS.MS') AND ROUTING_SERVICE_SK != -1 ORDER BY ORIGINATED_TIMESTAMP";

		System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadCDR_CONTACTS: Select Quesry: " + sql);

		ResultSet rs = stmt.executeQuery(sql);

		String insert_stmt = "INSERT INTO CDR_CONTACTS (ROUTING_POINT_SK, ROUTING_SERVICE_SK, ENGAGEMENT_SK, CONTACT_SK, ENGAGEMENT_ID, CONTACT_ID, CUSTOMER_ID, ORIGINATED_TIMESTAMP, END_TIMESTAMP, RING_TIME_DURATION, HANDLING_TIME_DURATION, HOLD_DURATION, ACTIVE_TIME_DURATION, ABANDONED_INDICATOR, INITIAL_DISPOSITION, FINAL_DISPOSITION, CONTACT_DURATION, CALLING_PARTY, IS_EXTERNAL, INCOMPLETE, SEGMENT_TYPE, TRANSFERRED_INDICATOR, CONSULT_INDICATOR, CONFERENCE_INDICATOR, TRANSFERRED_COUNT, CONSULT_COUNT, CONFERENCE_COUNT, DESTINATION_PARTY, PERSONAL_CONTACT_INDICATOR, WAIT_TIME_INDICATOR, WAIT_TIME, TREATMENT_INDICATOR, COVERAGE_INDICATOR, ROUTING_DURATION, DEFERRED_INDICATOR, AGENT_DISCONNECT_FIRST, LAST_ROUTING_SERVICE_SK, EMAIL_FORWARD_INDICATOR, CUSTOMER_CONTACT_END_TIMESTAMP, AUTO_REDACTED, CONVERSATION_THREAD_ID, MESSAGE_SOURCE_ID, LAST_CHANGED,REPLY_INDICATOR, SENT_FOR_APPROVAL_INDICATOR, APPROVAL_HANDLING_DURATION, REWORK_HANDLING_DURATION, INITIAL_WAIT_TIME_INDICATOR, INITIAL_WAIT_TIME) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?)";

		System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadCDR_CONTACTS: insert Quesry: " + insert_stmt);
		PreparedStatement mssqlstatement = mssqlcon.prepareStatement(insert_stmt);
		String dat = "";
		while (rs.next()) {
			// System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
			try {
				dat = rs.getString("ENGAGEMENT_ID") + "    " + rs.getString("CONTACT_ID");
				mssqlstatement.setLong(1, rs.getLong("ROUTING_POINT_SK"));
				mssqlstatement.setLong(2, rs.getLong("ROUTING_SERVICE_SK"));
				mssqlstatement.setLong(3, rs.getLong("ENGAGEMENT_SK"));
				mssqlstatement.setLong(4, rs.getLong("CONTACT_SK"));
				mssqlstatement.setString(5, rs.getString("ENGAGEMENT_ID"));
				mssqlstatement.setString(6, rs.getString("CONTACT_ID"));
				mssqlstatement.setString(7, rs.getString("CUSTOMER_ID"));
				mssqlstatement.setString(8, rs.getString("ORIGINATED_TIMESTAMP"));
				mssqlstatement.setString(9, rs.getString("END_TIMESTAMP"));
				mssqlstatement.setLong(10, rs.getLong("RING_TIME_DURATION"));
				mssqlstatement.setLong(11, rs.getLong("HANDLING_TIME_DURATION"));
				mssqlstatement.setLong(12, rs.getLong("HOLD_DURATION"));
				mssqlstatement.setLong(13, rs.getLong("ACTIVE_TIME_DURATION"));
				mssqlstatement.setString(14, rs.getString("ABANDONED_INDICATOR"));
				mssqlstatement.setString(15, rs.getString("INITIAL_DISPOSITION"));
				mssqlstatement.setString(16, rs.getString("FINAL_DISPOSITION"));
				mssqlstatement.setLong(17, rs.getLong("CONTACT_DURATION"));
				mssqlstatement.setString(18, rs.getString("CALLING_PARTY"));
				mssqlstatement.setString(19, rs.getString("IS_EXTERNAL"));
				mssqlstatement.setString(20, rs.getString("INCOMPLETE"));
				mssqlstatement.setString(21, rs.getString("SEGMENT_TYPE"));
				mssqlstatement.setString(22, rs.getString("TRANSFERRED_INDICATOR"));
				mssqlstatement.setString(23, rs.getString("CONSULT_INDICATOR"));
				mssqlstatement.setString(24, rs.getString("CONFERENCE_INDICATOR"));
				mssqlstatement.setInt(25, rs.getInt("TRANSFERRED_COUNT"));
				mssqlstatement.setInt(26, rs.getInt("CONSULT_COUNT"));
				mssqlstatement.setInt(27, rs.getInt("CONFERENCE_COUNT"));
				mssqlstatement.setString(28, rs.getString("DESTINATION_PARTY"));
				mssqlstatement.setString(29, rs.getString("PERSONAL_CONTACT_INDICATOR"));
				mssqlstatement.setString(30, rs.getString("WAIT_TIME_INDICATOR"));
				mssqlstatement.setLong(31, rs.getLong("WAIT_TIME"));
				mssqlstatement.setString(32, rs.getString("TREATMENT_INDICATOR"));
				mssqlstatement.setString(33, rs.getString("COVERAGE_INDICATOR"));
				mssqlstatement.setLong(34, rs.getLong("ROUTING_DURATION"));
				mssqlstatement.setString(35, rs.getString("DEFERRED_INDICATOR"));
				mssqlstatement.setString(36, rs.getString("AGENT_DISCONNECT_FIRST"));
				mssqlstatement.setLong(37, rs.getLong("LAST_ROUTING_SERVICE_SK"));
				mssqlstatement.setString(38, rs.getString("EMAIL_FORWARD_INDICATOR"));
				mssqlstatement.setString(39, rs.getString("ORIGINATED_TIMESTAMP"));
				mssqlstatement.setString(40, rs.getString("AUTO_REDACTED"));
				mssqlstatement.setString(41, rs.getString("CONVERSATION_THREAD_ID"));
				mssqlstatement.setString(42, rs.getString("MESSAGE_SOURCE_ID"));
				mssqlstatement.setString(43, rs.getString("LAST_CHANGED"));
				mssqlstatement.setString(44, rs.getString("REPLY_INDICATOR"));
				mssqlstatement.setString(45, rs.getString("SENT_FOR_APPROVAL_INDICATOR"));
				mssqlstatement.setLong(46, rs.getLong("APPROVAL_HANDLING_DURATION"));
				mssqlstatement.setLong(47, rs.getLong("REWORK_HANDLING_DURATION"));
				mssqlstatement.setString(48, rs.getString("INITIAL_WAIT_TIME_INDICATOR"));
				mssqlstatement.setLong(49, rs.getLong("INITIAL_WAIT_TIME"));

				// insert the data
				mssqlstatement.executeUpdate();
			} catch (Exception e) {
				System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + dat + ", exception occured: " + e);
				throw new Exception(e);
			}
		}
	}

	public static void loadCDR_SEGMENTS(Connection con, Connection mssqlcon) throws Exception {

		// Statement delete_stmt=mssqlcon.createStatement();
		// System.out.println("\n"+new Timestamp(new Date().getTime()) + " : "+"Deleting
		// CDR_SEGMENTS records on the same interval delete_stmt : " + "DELETE FROM
		// CDR_SEGMENTS WHERE ORIGINATED_TIMESTAMP >= '"+START_TIME+"' and
		// ORIGINATED_TIMESTAMP < '"+END_TIME+"'");
		// delete_stmt.executeUpdate("DELETE FROM CDR_SEGMENTS WHERE
		// ORIGINATED_TIMESTAMP >= '"+START_TIME+"' and ORIGINATED_TIMESTAMP <
		// '"+END_TIME+"'");

		Statement stmt = con.createStatement();

		String sql = "SELECT SEGMENT_SK, ROUTING_POINT_SK, ROUTING_SERVICE_SK, ENGAGEMENT_SK, CONTACT_SK, AGENT_SK, AGENT_CHANNEL_ADDRESS, ENGAGEMENT_ID, CONTACT_ID, SEGMENT_ID, TO_CHAR(ORIGINATED_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS ORIGINATED_TIMESTAMP, TO_CHAR(END_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS END_TIMESTAMP, RING_TIME_DURATION, ACTIVE_TIME_DURATION, HANDLING_TIME_DURATION, CONSULT_TIME_DURATION, AFTER_CALL_WORK_DURATION, ABANDONED_INDICATOR, RONA_INDICATOR, SEGMENT_DURATION, CALLING_PARTY, IS_EXTERNAL, INITIAL_DISPOSITION, FINAL_DISPOSITION, INCOMPLETE, SEGMENT_TYPE, TO_CHAR(ANSWER_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS ANSWER_TIMESTAMP, TO_CHAR(CUSTOMER_CONTACT_END_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS CUSTOMER_CONTACT_END_TIMESTAMP, ALERT_TIME_DURATION, DISCONNECT_FROM_HOLD_INDICATOR, TRANSFERRED_INDICATOR, CONSULT_INDICATOR, CONFERENCE_INDICATOR, HOLD_INDICATOR, HOLD_DURATION, BARGED_OUT_INDICATOR, COACHED_DURATION, COACHING_DURATION, OBSERVED_DURATION, OBSERVING_DURATION, BARGED_IN_DURATION, BARGED_OUT_DURATION, TO_CHAR(COACH_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS COACH_TIMESTAMP, TO_CHAR(BARGED_OUT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS BARGED_OUT_TIMESTAMP, HOLD_COUNT, TO_CHAR(OBSERVE_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS OBSERVE_TIMESTAMP, COACH_INDICATOR, COACHING_INDICATOR, BARGED_IN_INDICATOR, OBSERVED_INDICATOR, OBSERVING_INDICATOR, PERSONAL_CONTACT_INDICATOR, PERSONAL_OUTBOUND_INDICATOR, PERSONAL_INBOUND_INDICATOR, ROUTED_CONTACT_INDICATOR, DEFERRED_INDICATOR, DEFERRED_REASON_CODE_SK, RESERVED_INDICATOR, TO_CHAR(TRANSFER_INITIATED_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS TRANSFER_INITIATED_TIMESTAMP, TO_CHAR(TRANSFER_ACCEPTED_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS TRANSFER_ACCEPTED_TIMESTAMP, AUTO_REDACTED, TO_CHAR(LAST_CHANGED, 'YYYY-MM-DD HH24:MI:SS.MS') AS LAST_CHANGED, WORK_TYPE, APPROVED_INDICATOR, REJECTED_INDICATOR, REJECTION_REASON_CODE_SK FROM FACT.CDR_SEGMENTS WHERE ORIGINATED_TIMESTAMP >= TO_TIMESTAMP('"
				+ START_TIME + "', 'YYYY-MM-DD HH24:MI:SS.MS') AND ORIGINATED_TIMESTAMP < TO_TIMESTAMP('" + END_TIME
				+ "', 'YYYY-MM-DD HH24:MI:SS.MS') AND ROUTING_SERVICE_SK != -1 ORDER BY ORIGINATED_TIMESTAMP";

		System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadCDR_SEGMENTS: Select Quesry: " + sql);

		ResultSet rs = stmt.executeQuery(sql);

		String insert_stmt = "INSERT INTO CDR_SEGMENTS (SEGMENT_SK, ROUTING_POINT_SK, ROUTING_SERVICE_SK, ENGAGEMENT_SK, CONTACT_SK, AGENT_SK, AGENT_CHANNEL_ADDRESS, ENGAGEMENT_ID, CONTACT_ID, SEGMENT_ID, ORIGINATED_TIMESTAMP, END_TIMESTAMP, RING_TIME_DURATION, ACTIVE_TIME_DURATION, HANDLING_TIME_DURATION, CONSULT_TIME_DURATION, AFTER_CALL_WORK_DURATION, ABANDONED_INDICATOR, RONA_INDICATOR, SEGMENT_DURATION, CALLING_PARTY, IS_EXTERNAL, INITIAL_DISPOSITION, FINAL_DISPOSITION, INCOMPLETE, SEGMENT_TYPE, ANSWER_TIMESTAMP, CUSTOMER_CONTACT_END_TIMESTAMP, ALERT_TIME_DURATION, DISCONNECT_FROM_HOLD_INDICATOR, TRANSFERRED_INDICATOR, CONSULT_INDICATOR, CONFERENCE_INDICATOR, HOLD_INDICATOR, HOLD_DURATION, BARGED_OUT_INDICATOR, COACHED_DURATION, COACHING_DURATION, OBSERVED_DURATION, OBSERVING_DURATION, BARGED_IN_DURATION, BARGED_OUT_DURATION, COACH_TIMESTAMP, BARGED_OUT_TIMESTAMP, HOLD_COUNT, OBSERVE_TIMESTAMP, COACH_INDICATOR, COACHING_INDICATOR, BARGED_IN_INDICATOR, OBSERVED_INDICATOR, OBSERVING_INDICATOR, PERSONAL_CONTACT_INDICATOR, PERSONAL_OUTBOUND_INDICATOR, PERSONAL_INBOUND_INDICATOR, ROUTED_CONTACT_INDICATOR, DEFERRED_INDICATOR, DEFERRED_REASON_CODE_SK, RESERVED_INDICATOR, TRANSFER_INITIATED_TIMESTAMP, TRANSFER_ACCEPTED_TIMESTAMP, AUTO_REDACTED, LAST_CHANGED, WORK_TYPE, APPROVED_INDICATOR, REJECTED_INDICATOR, REJECTION_REASON_CODE_SK) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadCDR_SEGMENTS: insert Quesry: " + insert_stmt);
		PreparedStatement mssqlstatement = mssqlcon.prepareStatement(insert_stmt);

		while (rs.next()) {

			mssqlstatement.setLong(1, rs.getLong("SEGMENT_SK"));
			mssqlstatement.setLong(2, rs.getLong("ROUTING_POINT_SK"));
			mssqlstatement.setLong(3, rs.getLong("ROUTING_SERVICE_SK"));
			mssqlstatement.setLong(4, rs.getLong("ENGAGEMENT_SK"));
			mssqlstatement.setLong(5, rs.getLong("CONTACT_SK"));
			mssqlstatement.setLong(6, rs.getLong("AGENT_SK"));
			mssqlstatement.setString(7, rs.getString("AGENT_CHANNEL_ADDRESS"));
			mssqlstatement.setString(8, rs.getString("ENGAGEMENT_ID"));
			mssqlstatement.setString(9, rs.getString("CONTACT_ID"));
			mssqlstatement.setString(10, rs.getString("SEGMENT_ID"));
			mssqlstatement.setString(11, rs.getString("ORIGINATED_TIMESTAMP"));
			mssqlstatement.setString(12, rs.getString("END_TIMESTAMP"));
			mssqlstatement.setLong(13, rs.getLong("RING_TIME_DURATION"));
			mssqlstatement.setLong(14, rs.getLong("ACTIVE_TIME_DURATION"));
			mssqlstatement.setLong(15, rs.getLong("HANDLING_TIME_DURATION"));
			mssqlstatement.setLong(16, rs.getLong("CONSULT_TIME_DURATION"));
			mssqlstatement.setLong(17, rs.getLong("AFTER_CALL_WORK_DURATION"));
			mssqlstatement.setString(18, rs.getString("ABANDONED_INDICATOR"));
			mssqlstatement.setString(19, rs.getString("RONA_INDICATOR"));
			mssqlstatement.setLong(20, rs.getLong("SEGMENT_DURATION"));
			mssqlstatement.setString(21, rs.getString("CALLING_PARTY"));
			mssqlstatement.setString(22, rs.getString("IS_EXTERNAL"));
			mssqlstatement.setString(23, rs.getString("INITIAL_DISPOSITION"));
			mssqlstatement.setString(24, rs.getString("FINAL_DISPOSITION"));
			mssqlstatement.setString(25, rs.getString("INCOMPLETE"));
			mssqlstatement.setString(26, rs.getString("SEGMENT_TYPE"));
			mssqlstatement.setString(27, rs.getString("ANSWER_TIMESTAMP"));
			mssqlstatement.setString(28, rs.getString("CUSTOMER_CONTACT_END_TIMESTAMP"));
			mssqlstatement.setLong(29, rs.getLong("ALERT_TIME_DURATION"));
			mssqlstatement.setString(30, rs.getString("DISCONNECT_FROM_HOLD_INDICATOR"));
			mssqlstatement.setString(31, rs.getString("TRANSFERRED_INDICATOR"));
			mssqlstatement.setString(32, rs.getString("CONSULT_INDICATOR"));
			mssqlstatement.setString(33, rs.getString("CONFERENCE_INDICATOR"));
			mssqlstatement.setString(34, rs.getString("HOLD_INDICATOR"));
			mssqlstatement.setLong(35, rs.getLong("HOLD_DURATION"));
			mssqlstatement.setString(36, rs.getString("BARGED_OUT_INDICATOR"));
			mssqlstatement.setLong(37, rs.getLong("COACHED_DURATION"));
			mssqlstatement.setLong(38, rs.getLong("COACHING_DURATION"));
			mssqlstatement.setLong(39, rs.getLong("OBSERVED_DURATION"));
			mssqlstatement.setLong(40, rs.getLong("OBSERVING_DURATION"));
			mssqlstatement.setLong(41, rs.getLong("BARGED_IN_DURATION"));
			mssqlstatement.setLong(42, rs.getLong("BARGED_OUT_DURATION"));
			mssqlstatement.setString(43, rs.getString("COACH_TIMESTAMP"));
			mssqlstatement.setString(44, rs.getString("BARGED_OUT_TIMESTAMP"));
			mssqlstatement.setLong(45, rs.getLong("HOLD_COUNT"));
			mssqlstatement.setString(46, rs.getString("OBSERVE_TIMESTAMP"));
			mssqlstatement.setString(47, rs.getString("COACH_INDICATOR"));
			mssqlstatement.setString(48, rs.getString("COACHING_INDICATOR"));
			mssqlstatement.setString(49, rs.getString("BARGED_IN_INDICATOR"));
			mssqlstatement.setString(50, rs.getString("OBSERVED_INDICATOR"));
			mssqlstatement.setString(51, rs.getString("OBSERVING_INDICATOR"));
			mssqlstatement.setString(52, rs.getString("PERSONAL_CONTACT_INDICATOR"));
			mssqlstatement.setString(53, rs.getString("PERSONAL_OUTBOUND_INDICATOR"));
			mssqlstatement.setString(54, rs.getString("PERSONAL_INBOUND_INDICATOR"));
			mssqlstatement.setString(55, rs.getString("ROUTED_CONTACT_INDICATOR"));
			mssqlstatement.setString(56, rs.getString("DEFERRED_INDICATOR"));
			mssqlstatement.setLong(57, rs.getLong("DEFERRED_REASON_CODE_SK"));
			mssqlstatement.setString(58, rs.getString("RESERVED_INDICATOR"));
			mssqlstatement.setString(59, rs.getString("TRANSFER_INITIATED_TIMESTAMP"));
			mssqlstatement.setString(60, rs.getString("TRANSFER_ACCEPTED_TIMESTAMP"));
			mssqlstatement.setString(61, rs.getString("AUTO_REDACTED"));
			mssqlstatement.setString(62, rs.getString("LAST_CHANGED"));
			mssqlstatement.setString(63, rs.getString("WORK_TYPE"));
			mssqlstatement.setString(64, rs.getString("APPROVED_INDICATOR"));
			mssqlstatement.setString(65, rs.getString("REJECTED_INDICATOR"));
			mssqlstatement.setLong(66, rs.getLong("REJECTION_REASON_CODE_SK"));

			// insert the data
			mssqlstatement.executeUpdate();
		}
	}

	public static void loadDIM_ROUTING_SERVICES(Connection con, Connection mssqlcon) throws Exception {

		Statement stmt = con.createStatement();

		String sql = "SELECT ROUTING_SERVICE_SK, CHANNEL_ID, PROVIDER_ID, ROUTING_SERVICE_ID, ROUTING_SERVICE_NAME, ROUTING_SERVICE_CATEGORY_NAME, TO_CHAR(ROW_ACTIVE_DATE, 'YYYY-MM-DD HH:MI:SS.MS') AS ROW_ACTIVE_DATE, TO_CHAR(ROW_INACTIVE_DATE, 'YYYY-MM-DD HH:MI:SS.MS') AS ROW_INACTIVE_DATE, ACTIVE_RECORD, TO_CHAR(LAST_CHANGED, 'YYYY-MM-DD HH:MI:SS.MS') AS LAST_CHANGED FROM FACT.DIM_ROUTING_SERVICES";

		System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadDIM_ROUTING_SERVICES: Select Quesry: " + sql);

		ResultSet rs = stmt.executeQuery(sql);

		String insert_stmt = "INSERT INTO DIM_ROUTING_SERVICES (ROUTING_SERVICE_SK, CHANNEL_ID, PROVIDER_ID, ROUTING_SERVICE_ID, ROUTING_SERVICE_NAME, ROUTING_SERVICE_CATEGORY_NAME, ROW_ACTIVE_DATE, ROW_INACTIVE_DATE, ACTIVE_RECORD, LAST_CHANGED) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		System.out.println("\n" + new Timestamp(new Date().getTime()) + " : "+ "loadDIM_ROUTING_SERVICES: insert Quesry: " + insert_stmt);
		PreparedStatement mssqlstatement = mssqlcon.prepareStatement(insert_stmt);

		while (rs.next()) {

			mssqlstatement.setInt(1, rs.getInt("ROUTING_SERVICE_SK"));
			mssqlstatement.setString(2, rs.getString("CHANNEL_ID"));
			mssqlstatement.setString(3, rs.getString("PROVIDER_ID"));
			mssqlstatement.setString(4, rs.getString("ROUTING_SERVICE_ID"));
			mssqlstatement.setString(5, rs.getString("ROUTING_SERVICE_NAME"));
			mssqlstatement.setString(6, rs.getString("ROUTING_SERVICE_CATEGORY_NAME"));
			mssqlstatement.setString(7, rs.getString("ROW_ACTIVE_DATE"));
			mssqlstatement.setString(8, rs.getString("ROW_INACTIVE_DATE"));
			mssqlstatement.setString(9, rs.getString("ACTIVE_RECORD"));
			mssqlstatement.setString(10, rs.getString("LAST_CHANGED"));
			// insert the data
			mssqlstatement.executeUpdate();
		}
	}

	public static void loadDIM_AGENTS(Connection con, Connection mssqlcon) throws Exception {
		Statement stmt = con.createStatement();

		String sql = " SELECT AGENT_SK, SUPERVISOR_SK, AGENT_ID, AGENT_FIRST_NAME, AGENT_LAST_NAME, AGENT_DISPLAY_NAME, AGENT_USER_HANDLE, AGENT_TYPE, TO_CHAR(ROW_ACTIVE_DATE, 'YYYY-MM-DD HH24:MI:SS.MS') as ROW_ACTIVE_DATE,TO_CHAR(ROW_INACTIVE_DATE, 'YYYY-MM-DD HH24:MI:SS.MS') AS ROW_INACTIVE_DATE, ACTIVE_RECORD, TO_CHAR(LAST_CHANGED, 'YYYY-MM-DD HH24:MI:SS.MS') AS LAST_CHANGED FROM fact.DIM_AGENTS";

		System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadDIM_AGENTS: Select Query: " + sql);

		ResultSet rs = stmt.executeQuery(sql);

		String insert_stmt = "INSERT INTO DIM_AGENTS (AGENT_SK, SUPERVISOR_SK, AGENT_ID, AGENT_FIRST_NAME, AGENT_LAST_NAME, AGENT_DISPLAY_NAME, AGENT_USER_HANDLE, AGENT_TYPE, ROW_ACTIVE_DATE, ROW_INACTIVE_DATE, ACTIVE_RECORD, LAST_CHANGED) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadDIM_AGENTS: insert Query: " + insert_stmt);

		PreparedStatement mssqlstatement = mssqlcon.prepareStatement(insert_stmt);

		while (rs.next()) {
			mssqlstatement.setString(1, rs.getString("AGENT_SK"));
			mssqlstatement.setString(2, rs.getString("SUPERVISOR_SK"));
			mssqlstatement.setString(3, rs.getString("AGENT_ID"));
			mssqlstatement.setString(4, rs.getString("AGENT_FIRST_NAME"));
			mssqlstatement.setString(5, rs.getString("AGENT_LAST_NAME"));
			mssqlstatement.setString(6, rs.getString("AGENT_DISPLAY_NAME"));
			mssqlstatement.setString(7, rs.getString("AGENT_ID"));
			mssqlstatement.setString(8, rs.getString("AGENT_TYPE"));
			mssqlstatement.setString(9, rs.getString("ROW_ACTIVE_DATE"));
			mssqlstatement.setString(10, rs.getString("ROW_INACTIVE_DATE"));
			mssqlstatement.setString(11, rs.getString("ACTIVE_RECORD"));
			mssqlstatement.setString(12, rs.getString("LAST_CHANGED"));
			// insert the data
			mssqlstatement.executeUpdate();
		}
	}

	public static void loadDIM_NOT_READY_REASON_CODES(Connection con, Connection mssqlcon) throws Exception {

		/*
		 * Statement stmt=con.createStatement();
		 * 
		 * 
		 * //System.out.println("loadDIM_NOT_READY_REASON_CODES: Select Query: " + sql);
		 * 
		 * //ResultSet rs = stmt.executeQuery(sql);
		 * 
		 * String insert_stmt =
		 * "INSERT INTO DIM_NOT_READY_REASON_CODES (NOT_READY_REASON_CODE_SK, NOT_READY_REASON_CODE_ID, NOT_READY_REASON, NOT_READY_REASON_DESCRIPTION, ROW_ACTIVE_DATE, ROW_INACTIVE_DATE, ACTIVE_RECORD, LAST_CHANGED) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
		 * ;
		 * 
		 * System.out.println("loadCDR_CONTACTS: insert Query: " + insert_stmt);
		 * PreparedStatement mssqlstatement = mssqlcon.prepareStatement(insert_stmt);
		 * 
		 * while(rs.next()) {
		 * mssqlstatement.setInt(1,rs.getInt("NOT_READY_REASON_CODE_SK"));
		 * mssqlstatement.setString(2,rs.getString("NOT_READY_REASON_CODE_ID"));
		 * mssqlstatement.setString(3,rs.getString("NOT_READY_REASON"));
		 * mssqlstatement.setString(4,rs.getString("NOT_READY_REASON_DESCRIPTION"));
		 * 
		 * mssqlstatement.setString(5,rs.getString("ROW_ACTIVE_DATE"));
		 * mssqlstatement.setString(6,rs.getString("ROW_INACTIVE_DATE"));
		 * mssqlstatement.setString(7,rs.getString("ACTIVE_RECORD"));
		 * mssqlstatement.setString(8,rs.getString("LAST_CHANGED"));
		 * 
		 * // insert the data mssqlstatement.executeUpdate(); }
		 */}

	public static void updateAGENT_LOGON(Connection connection, Connection mssqlconnection) throws Exception {
		try {
			ResultSet result;
			String START_TIME1 = "(to_timestamp('" + START_TIME
					+ "', 'YYYY-MM-DD HH24:MI:SS.MS') - interval '24 hour')::timestamp";
			String END_TIME1 = START_TIME;

			String selectQuery = "SELECT AGENT_LOGON_SK, AGENT_SK, TO_CHAR(LOGIN_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS LOGIN_TIMESTAMP, TO_CHAR(LOGOUT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS LOGOUT_TIMESTAMP, LOGON_DURATION, STATUS, TO_CHAR(LAST_CHANGED, 'YYYY-MM-DD HH24:MI:SS.MS') AS LAST_CHANGED FROM FACT.AGENT_LOGON WHERE LOGIN_TIMESTAMP >= "
					+ START_TIME1 + " AND LOGIN_TIMESTAMP < TO_TIMESTAMP('" + END_TIME1
					+ "','YYYY-MM-DD HH24:MI:SS.MS') AND LOGOUT_TIMESTAMP IS NOT NULL";

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "updateAGENT_LOGON => selectQuery: "
					+ selectQuery);

			Statement statement = connection.createStatement();
			result = statement.executeQuery(selectQuery);

			String updateQuery = "";

			Statement preparedStatement = mssqlconnection.createStatement();

			while (result.next()) {
				updateQuery = "update agent_logon set AGENT_LOGON_SK=" + result.getLong("AGENT_LOGON_SK")
						+ ",LOGOUT_TIMESTAMP='" + result.getString("LOGOUT_TIMESTAMP") + "', LOGON_DURATION="
						+ result.getLong("LOGON_DURATION") + ", STATUS=" + result.getInt("STATUS") + ", LAST_CHANGED='"
						+ result.getString("LAST_CHANGED") + "' where AGENT_SK = " + result.getLong("AGENT_SK")
						+ " and LOGIN_TIMESTAMP = CONVERT(DATETIME,'" + result.getString("LOGIN_TIMESTAMP")
						+ "',121) and LOGOUT_TIMESTAMP IS NULL;";

				// System.out.println("updateQuery : " + updateQuery);
				preparedStatement.executeUpdate(updateQuery);
			}
		} catch (Exception e) {
			e.printStackTrace();
			// throw e;
		}
	}

	public static void loadAGENT_LOGON(Connection connection, Connection mssqlconnection) throws Exception {
		try {
			// Statement delete_stmt=mssqlconnection.createStatement();
			// System.out.println("\n"+new Timestamp(new Date().getTime()) + " : "+"Deleting
			// AGENT_LOGON records on the same interval delete_stmt : " + "DELETE FROM
			// AGENT_LOGON WHERE login_timestamp >= '"+START_TIME+"' and login_timestamp <
			// '"+END_TIME+"'");
			// delete_stmt.executeUpdate("DELETE FROM AGENT_LOGON WHERE login_timestamp >=
			// '"+START_TIME+"' and login_timestamp < '"+END_TIME+"'");

			ResultSet result;

			String selectQuery = "SELECT AGENT_LOGON_SK, AGENT_SK, TO_CHAR(LOGIN_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS LOGIN_TIMESTAMP, TO_CHAR(LOGOUT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS LOGOUT_TIMESTAMP, LOGON_DURATION, STATUS, TO_CHAR(LAST_CHANGED, 'YYYY-MM-DD HH24:MI:SS.MS') AS LAST_CHANGED FROM FACT.AGENT_LOGON WHERE login_timestamp >= TO_TIMESTAMP('"
					+ START_TIME + "','YYYY-MM-DD HH24:MI:SS.MS') AND login_timestamp < TO_TIMESTAMP('" + END_TIME
					+ "','YYYY-MM-DD HH24:MI:SS.MS')";

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadAGENT_LOGON => selectQuery: "
					+ selectQuery);

			Statement statement = connection.createStatement();
			result = statement.executeQuery(selectQuery);

			String insertQuery = "INSERT INTO AGENT_LOGON (AGENT_LOGON_SK, AGENT_SK, LOGIN_TIMESTAMP, LOGOUT_TIMESTAMP, LOGON_DURATION, STATUS, LAST_CHANGED) VALUES (?,?,?,?,?,?,?)";

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadAGENT_LOGON => insertQuery: "
					+ insertQuery);

			PreparedStatement preparedStatement = mssqlconnection.prepareStatement(insertQuery);

			while (result.next()) {
				preparedStatement.setLong(1, result.getLong("AGENT_LOGON_SK"));
				preparedStatement.setLong(2, result.getLong("AGENT_SK"));
				preparedStatement.setString(3, result.getString("LOGIN_TIMESTAMP"));
				preparedStatement.setString(4, result.getString("LOGOUT_TIMESTAMP"));
				preparedStatement.setLong(5, result.getLong("LOGON_DURATION"));
				preparedStatement.setInt(6, result.getInt("STATUS"));
				preparedStatement.setString(7, result.getString("LAST_CHANGED"));
				preparedStatement.executeUpdate();
			}

		} catch (Exception e) {
			e.printStackTrace();
			// throw e;
		}
	}

	public static void loadAGENT_BY_NOT_READY_REASON_CODE_INTERVAL(Connection connection, Connection mssqlconnection)
			throws Exception {
		try {

			// Statement delete_stmt=mssqlconnection.createStatement();
			// System.out.println("\n"+new Timestamp(new Date().getTime()) + " : Deleting
			// AGENT_BY_NOT_READY_REASON_CODE_INTERVAL records on the same interval
			// delete_stmt : " + "DELETE FROM AGENT_BY_NOT_READY_REASON_CODE_INTERVAL WHERE
			// interval_start_timestamp >= '"+START_TIME+"' and interval_start_timestamp <
			// '"+END_TIME+"'");
			// delete_stmt.executeUpdate("DELETE FROM
			// AGENT_BY_NOT_READY_REASON_CODE_INTERVAL WHERE interval_start_timestamp >=
			// '"+START_TIME+"' and interval_start_timestamp < '"+END_TIME+"'");

			String selectQuery = "SELECT ETL_TICKET_ID, TO_CHAR(INTERVAL_START_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.MS') AS INTERVAL_START_TIMESTAMP, TO_CHAR(LAST_CHANGED, 'YYYY-MM-DD HH24:MI:SS.MS') AS LAST_CHANGED, UTC_QUARTER_HOUR_SK, AGENT_SK, NOT_READY_REASON_CODE_SK , NR_REASONCODE_OCCURRENCES, TIME_IN_NR_REASONCODE FROM FACT.AGENT_BY_NOT_READY_REASON_CODE_INTERVAL where time_in_nr_reasoncode > 0 and interval_start_timestamp >= TO_TIMESTAMP('"
					+ START_TIME + "', 'YYYY-MM-DD HH24:MI:SS.MS') AND interval_start_timestamp < TO_TIMESTAMP('"
					+ END_TIME + "', 'YYYY-MM-DD HH24:MI:SS.MS')";

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : "
					+ "loadAGENT_BY_NOT_READY_REASON_CODE_INTERVAL => " + selectQuery);

			Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery(selectQuery);

			String insertQuery = "INSERT INTO AGENT_BY_NOT_READY_REASON_CODE_INTERVAL (ETL_TICKET_ID, INTERVAL_START_TIMESTAMP,  LAST_CHANGED,UTC_QUARTER_HOUR_SK, AGENT_SK, NOT_READY_REASON_CODE_SK, NR_REASONCODE_OCCURRENCES,TIME_IN_NR_REASONCODE) VALUES (?,?,?,?,?,?,?,?)";

			PreparedStatement preparedStatement = mssqlconnection.prepareStatement(insertQuery);

			while (result.next()) {
				preparedStatement.setLong(1, result.getLong("ETL_TICKET_ID"));
				preparedStatement.setString(2, result.getString("INTERVAL_START_TIMESTAMP"));
				preparedStatement.setString(3, result.getString("LAST_CHANGED"));
				preparedStatement.setLong(4, result.getLong("UTC_QUARTER_HOUR_SK"));
				preparedStatement.setInt(5, result.getInt("AGENT_SK"));
				preparedStatement.setInt(6, result.getInt("NOT_READY_REASON_CODE_SK"));
				preparedStatement.setInt(7, result.getInt("NR_REASONCODE_OCCURRENCES"));
				preparedStatement.setLong(8, result.getLong("TIME_IN_NR_REASONCODE"));
				preparedStatement.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static void loadAGENT_INTERVAL(Connection connection, Connection mssqlconnection) throws Exception {
		try {

			// Statement delete_stmt=mssqlconnection.createStatement();
			// System.out.println("\n"+new Timestamp(new Date().getTime()) + " : Deleting
			// agent_interval records on the same interval delete_stmt : " + "DELETE FROM
			// agent_interval WHERE interval_start_timestamp >= '"+START_TIME+"' and
			// interval_start_timestamp < '"+END_TIME+"'");
			// delete_stmt.executeUpdate("DELETE FROM agent_interval WHERE
			// interval_start_timestamp >= '"+START_TIME+"' and interval_start_timestamp <
			// '"+END_TIME+"'");

			ResultSet result;

			String selectQuery = "Select etl_ticket_id, TO_CHAR(interval_start_timestamp, 'YYYY-MM-DD HH24:MI:SS.MS') AS interval_start_timestamp, TO_CHAR(last_changed, 'YYYY-MM-DD HH24:MI:SS.MS') AS last_changed, utc_quarter_hour_sk, agent_sk, abandoned, active_time_duration, acw, acw_duration, acw_extended, additional_work, additional_work_duration, adhoc, adhoc_duration, alert_duration, answered, barged_in, barged_in_duration, barged_out, barged_out_duration, blended_active, blended_active_duration, blended_alert, blended_alert_duration, coached, coached_duration, coaching, coaching_duration, comp_active_time_duration, comp_acw, comp_acw_extended, comp_adhoc, comp_adhoc_duration, comp_alert_duration, comp_answered, comp_barged_in, comp_barged_in_duration, comp_barged_out, comp_barged_out_duration, comp_blended_active, comp_blended_active_duration, comp_blended_alert, comp_blended_alert_duration, comp_coached, comp_coached_duration, comp_coaching, comp_coaching_duration, comp_conferenced, comp_conferenced_accepted, comp_conferenced_initiated, comp_consult_duration, comp_consulted_duration, comp_consulting_duration, comp_consults, comp_consults_accepted, comp_consults_accept_from_agnt, comp_consults_accept_from_serv, comp_consults_initiated, comp_consults_init_to_agent, comp_consults_init_to_service, comp_hold_duration, comp_holds, completed, comp_long_acw, comp_long_holds, comp_observed, comp_observed_duration, comp_observing, comp_observing_duration, comp_offered, comp_short_acw, comp_trans_accept_from_agent, comp_trans_accept_from_service, comp_transferred, comp_transferred_accepted, comp_transferred_initiated, comp_transferred_to_agent, comp_transferred_to_service, comp_trans_initiate_to_agent, comp_trans_initiate_to_service, conferenced, conferenced_accepted, conferenced_accepted_from_agent, conferenced_accepted_from_service, conferenced_initiated, conferenced_initiate_to_agent, conferenced_initiate_to_service, consult_duration, consulted_duration, consulting_duration, consults, consults_accepted, consults_accept_from_agent, consults_accept_from_service, consults_initiated, consults_initiate_to_agent, consults_initiate_to_service, deferred_contacts, disconnects_from_hold, email_forward, hold_duration, holds, idle_time_duration, logon_duration, long_acw, long_engagements, long_holds, not_answered, not_ready_count, not_ready_time_duration, observed, observed_duration, observing, observing_duration, offered, personal_inbound_contacts, personal_inbound_duration, personal_outbound_contacts, personal_outbound_duration, repeated_deferrals, replied, short_acw, short_engagements, short_not_ready, super_defer_completed, super_defer_transferred, trans_accept_from_agent, trans_accept_from_service, transferred, transferred_accepted, transferred_initiated, transferred_to_agent, transferred_to_service, trans_initiate_to_agent, trans_initiate_to_service, approval_active_time_duration, approval_answered, approval_requeued, approval_review_approved, approval_review_rejected, comp_approval_active_time_duration, comp_approval_answered, comp_rework_active_time_duration, comp_rework_answered, rework_active_time_duration, rework_answered, rework_closed, rework_replied, sent_for_approval, work_approved, work_rejected from fact.agent_interval WHERE interval_start_timestamp >= TO_TIMESTAMP('"
					+ START_TIME + "', 'YYYY-MM-DD HH24:MI:SS.MS') AND interval_start_timestamp < TO_TIMESTAMP('"
					+ END_TIME + "', 'YYYY-MM-DD HH24:MI:SS.MS') and logon_duration >0";
			Statement statement = connection.createStatement();
			result = statement.executeQuery(selectQuery);

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadAGENT_INTERVAL selectQuery: "
					+ selectQuery);

			// Statement mssqlstatement=mssqlconnection.createStatement();
			// mssqlstatement.executeUpdate("DELETE FROM agent_interval");

			String insertQuery = "INSERT INTO agent_interval ([etl_ticket_id],[interval_start_timestamp],[last_changed],[utc_quarter_hour_sk],[agent_sk],[abandoned],[active_time_duration],[acw],[acw_duration],[acw_extended],[additional_work],[additional_work_duration],[adhoc],[adhoc_duration],[alert_duration],[answered],[barged_in],[barged_in_duration],[barged_out],[barged_out_duration],[blended_active],[blended_active_duration],[blended_alert] ,[blended_alert_duration] ,[coached] ,[coached_duration] ,[coaching] ,[coaching_duration] ,[comp_active_time_duration] ,[comp_acw] ,[comp_acw_extended] ,[comp_adhoc] ,[comp_adhoc_duration] ,[comp_alert_duration] ,[comp_answered] ,[comp_barged_in] ,[comp_barged_in_duration] ,[comp_barged_out] ,[comp_barged_out_duration] ,[comp_blended_active] ,[comp_blended_active_duration] ,[comp_blended_alert] ,[comp_blended_alert_duration] ,[comp_coached] ,[comp_coached_duration] ,[comp_coaching] ,[comp_coaching_duration] ,[comp_conferenced] ,[comp_conferenced_accepted] ,[comp_conferenced_initiated] ,[comp_consult_duration] ,[comp_consulted_duration] ,[comp_consulting_duration] ,[comp_consults] ,[comp_consults_accepted] ,[comp_consults_accept_from_agnt] ,[comp_consults_accept_from_serv] ,[comp_consults_initiated] ,[comp_consults_init_to_agent] ,[comp_consults_init_to_service] ,[comp_hold_duration] ,[comp_holds] ,[completed] ,[comp_long_acw] ,[comp_long_holds] ,[comp_observed] ,[comp_observed_duration] ,[comp_observing] ,[comp_observing_duration] ,[comp_offered] ,[comp_short_acw] ,[comp_trans_accept_from_agent] ,[comp_trans_accept_from_service] ,[comp_transferred] ,[comp_transferred_accepted] ,[comp_transferred_initiated] ,[comp_transferred_to_agent],[comp_transferred_to_service],[comp_trans_initiate_to_agent],[comp_trans_initiate_to_service] ,[conferenced] ,[conferenced_accepted] ,[conferenced_accepted_from_agent] ,[conferenced_accepted_from_service] ,[conferenced_initiated] ,[conferenced_initiate_to_agent] ,[conferenced_initiate_to_service] ,[consult_duration] ,[consulted_duration] ,[consulting_duration] ,[consults] ,[consults_accepted] ,[consults_accept_from_agent] ,[consults_accept_from_service] ,[consults_initiated] ,[consults_initiate_to_agent] ,[consults_initiate_to_service] ,[deferred_contacts] ,[disconnects_from_hold] ,[email_forward] ,[hold_duration] ,[holds] ,[idle_time_duration] ,[logon_duration] ,[long_acw] ,[long_engagements] ,[long_holds] ,[not_answered] ,[not_ready_count] ,[not_ready_time_duration] ,[observed] ,[observed_duration] ,[observing] ,[observing_duration] ,[offered] ,[personal_inbound_contacts] ,[personal_inbound_duration] ,[personal_outbound_contacts] ,[personal_outbound_duration] ,[repeated_deferrals] ,[replied] ,[short_acw] ,[short_engagements] ,[short_not_ready] ,[super_defer_completed] ,[super_defer_transferred] ,[trans_accept_from_agent] ,[trans_accept_from_service] ,[transferred] ,[transferred_accepted] ,[transferred_initiated] ,[transferred_to_agent] ,[transferred_to_service] ,[trans_initiate_to_agent] ,[trans_initiate_to_service], approval_active_time_duration, approval_answered, approval_requeued, approval_review_approved, approval_review_rejected, comp_approval_active_time_duration, comp_approval_answered, comp_rework_active_time_duration, comp_rework_answered, rework_active_time_duration, rework_answered, rework_closed, rework_replied, sent_for_approval, work_approved, work_rejected) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "loadAGENT_INTERVAL insertQuery: "
					+ insertQuery);

			PreparedStatement preparedStatement = mssqlconnection.prepareStatement(insertQuery);
			while (result.next()) {
				preparedStatement.setLong(1, result.getLong("etl_ticket_id"));
				preparedStatement.setString(2, result.getString("interval_start_timestamp"));
				preparedStatement.setString(3, result.getString("last_changed"));
				preparedStatement.setLong(4, result.getLong("utc_quarter_hour_sk"));
				preparedStatement.setInt(5, result.getInt("agent_sk"));
				preparedStatement.setInt(6, result.getInt("abandoned"));
				preparedStatement.setLong(7, result.getLong("active_time_duration"));
				preparedStatement.setInt(8, result.getInt("acw"));
				preparedStatement.setLong(9, result.getLong("acw_duration"));
				preparedStatement.setInt(10, result.getInt("acw_extended"));
				preparedStatement.setInt(11, result.getInt("additional_work"));
				preparedStatement.setLong(12, result.getLong("additional_work_duration"));
				preparedStatement.setInt(13, result.getInt("adhoc"));
				preparedStatement.setLong(14, result.getLong("adhoc_duration"));
				preparedStatement.setLong(15, result.getLong("alert_duration"));
				preparedStatement.setInt(16, result.getInt("answered"));
				preparedStatement.setInt(17, result.getInt("barged_in"));
				preparedStatement.setLong(18, result.getLong("barged_in_duration"));
				preparedStatement.setInt(19, result.getInt("barged_out"));
				preparedStatement.setLong(20, result.getLong("barged_out_duration"));
				preparedStatement.setInt(21, result.getInt("blended_active"));
				preparedStatement.setLong(22, result.getLong("blended_active_duration"));
				preparedStatement.setInt(23, result.getInt("blended_alert"));
				preparedStatement.setLong(24, result.getLong("blended_alert_duration"));
				preparedStatement.setInt(25, result.getInt("coached"));
				preparedStatement.setLong(26, result.getLong("coached_duration"));
				preparedStatement.setInt(27, result.getInt("coaching"));
				preparedStatement.setLong(28, result.getLong("coaching_duration"));
				preparedStatement.setLong(29, result.getLong("comp_active_time_duration"));
				preparedStatement.setInt(30, result.getInt("comp_acw"));
				preparedStatement.setInt(31, result.getInt("comp_acw_extended"));
				preparedStatement.setInt(32, result.getInt("comp_adhoc"));
				preparedStatement.setLong(33, result.getLong("comp_adhoc_duration"));
				preparedStatement.setLong(34, result.getLong("comp_alert_duration"));
				preparedStatement.setInt(35, result.getInt("comp_answered"));
				preparedStatement.setInt(36, result.getInt("comp_barged_in"));
				preparedStatement.setLong(37, result.getLong("comp_barged_in_duration"));
				preparedStatement.setInt(38, result.getInt("comp_barged_out"));
				preparedStatement.setLong(39, result.getLong("comp_barged_out_duration"));
				preparedStatement.setInt(40, result.getInt("comp_blended_active"));
				preparedStatement.setLong(41, result.getLong("comp_blended_active_duration"));
				preparedStatement.setInt(42, result.getInt("comp_blended_alert"));
				preparedStatement.setLong(43, result.getLong("comp_blended_alert_duration"));
				preparedStatement.setInt(44, result.getInt("comp_coached"));
				preparedStatement.setLong(45, result.getLong("comp_coached_duration"));
				preparedStatement.setInt(46, result.getInt("comp_coaching"));
				preparedStatement.setLong(47, result.getLong("comp_coaching_duration"));
				preparedStatement.setInt(48, result.getInt("comp_conferenced"));
				preparedStatement.setInt(49, result.getInt("comp_conferenced_accepted"));
				preparedStatement.setInt(50, result.getInt("comp_conferenced_initiated"));
				preparedStatement.setLong(51, result.getLong("comp_consult_duration"));
				preparedStatement.setLong(52, result.getLong("comp_consulted_duration"));
				preparedStatement.setLong(53, result.getLong("comp_consulting_duration"));
				preparedStatement.setInt(54, result.getInt("comp_consults"));
				preparedStatement.setInt(55, result.getInt("comp_consults_accepted"));
				preparedStatement.setInt(56, result.getInt("comp_consults_accept_from_agnt"));
				preparedStatement.setInt(57, result.getInt("comp_consults_accept_from_serv"));
				preparedStatement.setInt(58, result.getInt("comp_consults_initiated"));
				preparedStatement.setInt(59, result.getInt("comp_consults_init_to_agent"));
				preparedStatement.setInt(60, result.getInt("comp_consults_init_to_service"));
				preparedStatement.setLong(61, result.getLong("comp_hold_duration"));
				preparedStatement.setInt(62, result.getInt("comp_holds"));
				preparedStatement.setInt(63, result.getInt("completed"));
				preparedStatement.setInt(64, result.getInt("comp_long_acw"));
				preparedStatement.setInt(65, result.getInt("comp_long_holds"));
				preparedStatement.setInt(66, result.getInt("comp_observed"));
				preparedStatement.setLong(67, result.getLong("comp_observed_duration"));
				preparedStatement.setInt(68, result.getInt("comp_observing"));
				preparedStatement.setLong(69, result.getLong("comp_observing_duration"));
				preparedStatement.setInt(70, result.getInt("comp_offered"));
				preparedStatement.setInt(71, result.getInt("comp_short_acw"));
				preparedStatement.setInt(72, result.getInt("comp_trans_accept_from_agent"));
				preparedStatement.setInt(73, result.getInt("comp_trans_accept_from_service"));
				preparedStatement.setInt(74, result.getInt("comp_transferred"));
				preparedStatement.setInt(75, result.getInt("comp_transferred_accepted"));
				preparedStatement.setInt(76, result.getInt("comp_transferred_initiated"));
				preparedStatement.setInt(77, result.getInt("comp_transferred_to_agent"));
				preparedStatement.setInt(78, result.getInt("comp_transferred_to_service"));
				preparedStatement.setInt(79, result.getInt("comp_trans_initiate_to_agent"));
				preparedStatement.setInt(80, result.getInt("comp_trans_initiate_to_service"));
				preparedStatement.setInt(81, result.getInt("conferenced"));
				preparedStatement.setInt(82, result.getInt("conferenced_accepted"));
				preparedStatement.setInt(83, result.getInt("conferenced_accepted_from_agent"));
				preparedStatement.setInt(84, result.getInt("conferenced_accepted_from_service"));
				preparedStatement.setInt(85, result.getInt("conferenced_initiated"));
				preparedStatement.setInt(86, result.getInt("conferenced_initiate_to_agent"));
				preparedStatement.setInt(87, result.getInt("conferenced_initiate_to_service"));
				preparedStatement.setLong(88, result.getLong("consult_duration"));
				preparedStatement.setLong(89, result.getLong("consulted_duration"));
				preparedStatement.setLong(90, result.getLong("consulting_duration"));
				preparedStatement.setInt(91, result.getInt("consults"));
				preparedStatement.setInt(92, result.getInt("consults_accepted"));
				preparedStatement.setInt(93, result.getInt("consults_accept_from_agent"));
				preparedStatement.setInt(94, result.getInt("consults_accept_from_service"));
				preparedStatement.setInt(95, result.getInt("consults_initiated"));
				preparedStatement.setInt(96, result.getInt("consults_initiate_to_agent"));
				preparedStatement.setInt(97, result.getInt("consults_initiate_to_service"));
				preparedStatement.setInt(98, result.getInt("deferred_contacts"));
				preparedStatement.setInt(99, result.getInt("disconnects_from_hold"));
				preparedStatement.setInt(100, result.getInt("email_forward"));
				preparedStatement.setLong(101, result.getLong("hold_duration"));
				preparedStatement.setInt(102, result.getInt("holds"));
				preparedStatement.setLong(103, result.getLong("idle_time_duration"));
				preparedStatement.setLong(104, result.getLong("logon_duration"));
				preparedStatement.setInt(105, result.getInt("long_acw"));
				preparedStatement.setInt(106, result.getInt("long_engagements"));
				preparedStatement.setInt(107, result.getInt("long_holds"));
				preparedStatement.setInt(108, result.getInt("not_answered"));
				preparedStatement.setInt(109, result.getInt("not_ready_count"));
				preparedStatement.setLong(110, result.getLong("not_ready_time_duration"));
				preparedStatement.setInt(111, result.getInt("observed"));
				preparedStatement.setLong(112, result.getLong("observed_duration"));
				preparedStatement.setInt(113, result.getInt("observing"));
				preparedStatement.setLong(114, result.getLong("observing_duration"));
				preparedStatement.setInt(115, result.getInt("offered"));
				preparedStatement.setInt(116, result.getInt("personal_inbound_contacts"));
				preparedStatement.setLong(117, result.getLong("personal_inbound_duration"));
				preparedStatement.setInt(118, result.getInt("personal_outbound_contacts"));
				preparedStatement.setLong(119, result.getLong("personal_outbound_duration"));
				preparedStatement.setInt(120, result.getInt("repeated_deferrals"));
				preparedStatement.setInt(121, result.getInt("replied"));
				preparedStatement.setInt(122, result.getInt("short_acw"));
				preparedStatement.setInt(123, result.getInt("short_engagements"));
				preparedStatement.setInt(124, result.getInt("short_not_ready"));
				preparedStatement.setInt(125, result.getInt("super_defer_completed"));
				preparedStatement.setInt(126, result.getInt("super_defer_transferred"));
				preparedStatement.setInt(127, result.getInt("trans_accept_from_agent"));
				preparedStatement.setInt(128, result.getInt("trans_accept_from_service"));
				preparedStatement.setInt(129, result.getInt("transferred"));
				preparedStatement.setInt(130, result.getInt("transferred_accepted"));
				preparedStatement.setInt(131, result.getInt("transferred_initiated"));
				preparedStatement.setInt(132, result.getInt("transferred_to_agent"));
				preparedStatement.setInt(133, result.getInt("transferred_to_service"));
				preparedStatement.setInt(134, result.getInt("trans_initiate_to_agent"));
				preparedStatement.setInt(135, result.getInt("trans_initiate_to_service"));

				preparedStatement.setLong(136, result.getLong("approval_active_time_duration"));
				preparedStatement.setInt(137, result.getInt("approval_answered"));
				preparedStatement.setInt(138, result.getInt("approval_requeued"));
				preparedStatement.setInt(139, result.getInt("approval_review_approved"));
				preparedStatement.setInt(140, result.getInt("approval_review_rejected"));
				preparedStatement.setLong(141, result.getLong("comp_approval_active_time_duration"));
				preparedStatement.setInt(142, result.getInt("comp_approval_answered"));
				preparedStatement.setLong(143, result.getLong("comp_rework_active_time_duration"));
				preparedStatement.setInt(144, result.getInt("comp_rework_answered"));
				preparedStatement.setLong(145, result.getLong("rework_active_time_duration"));
				preparedStatement.setInt(146, result.getInt("rework_answered"));
				preparedStatement.setInt(147, result.getInt("rework_closed"));
				preparedStatement.setInt(148, result.getInt("rework_replied"));
				preparedStatement.setInt(149, result.getInt("sent_for_approval"));
				preparedStatement.setInt(150, result.getInt("work_approved"));
				preparedStatement.setInt(151, result.getInt("work_rejected"));

				preparedStatement.executeUpdate();
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static void loadROUTING_SERVICE_INTERVAL_DATA(Connection connection, Connection mssqlconnection)
			throws Exception {
		try {

			// Statement delete_stmt=mssqlconnection.createStatement();
			// System.out.println("\n"+new Timestamp(new Date().getTime()) + " : Deleting
			// routing_service_interval records on the same interval delete_stmt : " +
			// "DELETE FROM routing_service_interval WHERE interval_start_timestamp >=
			// '"+START_TIME+"' and interval_start_timestamp < '"+END_TIME+"'");
			// delete_stmt.executeUpdate("DELETE FROM routing_service_interval WHERE
			// interval_start_timestamp >= '"+START_TIME+"' and interval_start_timestamp <
			// '"+END_TIME+"'");

			String selectQuery = "SELECT etl_ticket_id,TO_CHAR(interval_start_timestamp, 'YYYY-MM-DD HH24:MI:SS.MS') AS interval_start_timestamp,TO_CHAR(last_changed, 'YYYY-MM-DD HH24:MI:SS.MS') AS last_changed,utc_quarter_hour_sk  ,routing_service_sk,abandoned ,abandoned_from_alerting ,abandoned_from_queue ,abandon_time_duration ,active_time_duration ,acw ,acw_duration ,acw_extended ,answered ,average_staffed_occurrences ,barged_in ,barged_in_duration ,barged_out ,barged_out_duration ,calls_aband_after_threshold ,calls_ans_after_threshold ,coached ,coached_duration ,coaching ,coaching_duration ,comp_abandon_time_duration ,comp_active_time_duration ,comp_acw ,comp_acw_extended ,comp_ans_after_threshold ,comp_answered ,comp_barged_in ,comp_barged_in_duration ,comp_barged_out ,comp_barged_out_duration ,comp_coached ,comp_coached_duration ,comp_coaching ,comp_coaching_duration ,comp_conferenced ,comp_conferenced_initiated ,comp_consult_duration ,comp_consulted_duration ,comp_consulting_duration ,comp_consults ,comp_consults_accepted ,comp_consults_accept_from_agnt ,comp_consults_accept_from_serv ,comp_consults_initiated ,comp_consults_init_to_agent ,comp_consults_init_to_service ,comp_hold_duration ,comp_holds ,completed ,comp_long_acw ,comp_long_holds ,comp_observed ,comp_observed_duration ,comp_observing ,comp_observing_duration ,comp_offered ,comp_ring_time_duration ,comp_short_acw ,comp_trans_accept_from_agent ,comp_trans_accept_from_service ,comp_transferred ,comp_transferred_initiated ,comp_transferred_to_agent ,comp_transferred_to_service ,comp_trans_initiate_to_agent ,comp_trans_initiate_to_service ,comp_wait_time ,conferenced ,conferenced_accepted ,conferenced_accepted_from_agent ,conferenced_accepted_from_service ,conferenced_initiated ,conferenced_initiate_to_agent ,conferenced_initiate_to_service ,consult_duration ,consulted_duration ,consulting_duration ,consults ,consults_accepted ,consults_accept_from_agent ,consults_accept_from_service ,consults_initiated ,consults_initiate_to_agent ,consults_initiate_to_service ,deferred_contacts ,email_forward ,hold_duration ,holds ,long_acw ,long_engagements ,long_holds ,max_staffed ,max_wait_duration ,not_answered ,observed ,observed_duration ,observing ,observing_duration ,offered ,repeated_deferrals ,replied ,ring_time_duration ,short_acw ,short_engagements ,super_defer_completed ,super_defer_transferred ,tot_duration ,trans_accept_from_agent ,trans_accept_from_service ,transferred ,transferred_accepted ,transferred_initiated ,transferred_to_agent ,transferred_to_service ,trans_initiate_to_agent ,trans_initiate_to_service ,wait_time, approval_active_time_duration ,approval_answered ,approval_requeued ,approval_review_approved ,approval_review_rejected ,comp_approval_active_time_duration ,comp_approval_answered ,  comp_rework_active_time_duration ,  comp_rework_answered ,rework_active_time_duration ,  rework_answered ,  rework_closed ,rework_replied ,   sent_for_approval ,work_approved ,work_rejected   from fact.routing_service_interval where  interval_start_timestamp >= TO_TIMESTAMP('"
					+ START_TIME + "', 'YYYY-MM-DD HH24:MI:SS.MS') AND interval_start_timestamp < TO_TIMESTAMP('"
					+ END_TIME + "', 'YYYY-MM-DD HH24:MI:SS.MS');";

			Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery(selectQuery);

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : "
					+ "loadROUTING_SERVICE_INTERVAL_DATA select query=" + selectQuery);

			String insertQuery = "INSERT INTO routing_service_interval (etl_ticket_id,interval_start_timestamp,last_changed,utc_quarter_hour_sk,routing_service_sk,abandoned,abandoned_from_alerting,abandoned_from_queue,abandon_time_duration,active_time_duration,acw,acw_duration,acw_extended,answered,average_staffed_occurrences,barged_in,barged_in_duration,barged_out,barged_out_duration,calls_aband_after_threshold,calls_ans_after_threshold,coached,coached_duration,coaching,coaching_duration,comp_abandon_time_duration,comp_active_time_duration,comp_acw,comp_acw_extended,comp_ans_after_threshold,comp_answered,comp_barged_in,comp_barged_in_duration,comp_barged_out,comp_barged_out_duration,comp_coached,comp_coached_duration,comp_coaching,comp_coaching_duration,comp_conferenced,comp_conferenced_initiated,comp_consult_duration,comp_consulted_duration,comp_consulting_duration,comp_consults,comp_consults_accepted,comp_consults_accept_from_agnt,comp_consults_accept_from_serv,comp_consults_initiated,comp_consults_init_to_agent,comp_consults_init_to_service,comp_hold_duration,comp_holds,completed,comp_long_acw,comp_long_holds,comp_observed,comp_observed_duration,comp_observing,comp_observing_duration,comp_offered,comp_ring_time_duration,comp_short_acw,comp_trans_accept_from_agent,comp_trans_accept_from_service,comp_transferred,comp_transferred_initiated,comp_transferred_to_agent,comp_transferred_to_service,comp_trans_initiate_to_agent,comp_trans_initiate_to_service,comp_wait_time,conferenced,conferenced_accepted,conferenced_accepted_from_agent,conferenced_accepted_from_service,conferenced_initiated,conferenced_initiate_to_agent,conferenced_initiate_to_service,consult_duration,consulted_duration,consulting_duration,consults,consults_accepted,consults_accept_from_agent,consults_accept_from_service,consults_initiated,consults_initiate_to_agent,consults_initiate_to_service,deferred_contacts,email_forward,hold_duration,holds,long_acw,long_engagements,long_holds,max_staffed,max_wait_duration,not_answered,observed,observed_duration,observing,observing_duration,offered,repeated_deferrals,replied,ring_time_duration,short_acw,short_engagements,super_defer_completed,super_defer_transferred,tot_duration,trans_accept_from_agent,trans_accept_from_service,transferred,transferred_accepted,transferred_initiated,transferred_to_agent,transferred_to_service,trans_initiate_to_agent,trans_initiate_to_service,wait_time,approval_active_time_duration ,approval_answered ,approval_requeued ,approval_review_approved ,approval_review_rejected ,comp_approval_active_time_duration ,comp_approval_answered ,  comp_rework_active_time_duration ,  comp_rework_answered ,rework_active_time_duration ,  rework_answered ,  rework_closed ,rework_replied ,   sent_for_approval ,work_approved ,work_rejected) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : "
					+ "loadROUTING_SERVICE_INTERVAL_DATA insertQuery =" + insertQuery);

			PreparedStatement preparedStatement = mssqlconnection.prepareStatement(insertQuery);
			while (result.next()) {
				preparedStatement.setLong(1, result.getLong("etl_ticket_id"));
				preparedStatement.setString(2, result.getString("interval_start_timestamp"));
				preparedStatement.setString(3, result.getString("last_changed"));
				preparedStatement.setLong(4, result.getLong("utc_quarter_hour_sk"));
				preparedStatement.setInt(5, result.getInt("routing_service_sk"));
				preparedStatement.setInt(6, result.getInt("abandoned"));
				preparedStatement.setInt(7, result.getInt("abandoned_from_alerting"));
				preparedStatement.setInt(8, result.getInt("abandoned_from_queue"));
				preparedStatement.setLong(9, result.getLong("abandon_time_duration"));
				preparedStatement.setLong(10, result.getLong("active_time_duration"));
				preparedStatement.setInt(11, result.getInt("acw"));
				preparedStatement.setLong(12, result.getLong("acw_duration"));
				preparedStatement.setInt(13, result.getInt("acw_extended"));
				preparedStatement.setInt(14, result.getInt("answered"));
				preparedStatement.setInt(15, result.getInt("average_staffed_occurrences"));
				preparedStatement.setInt(16, result.getInt("barged_in"));
				preparedStatement.setLong(17, result.getLong("barged_in_duration"));
				preparedStatement.setInt(18, result.getInt("barged_out"));
				preparedStatement.setLong(19, result.getLong("barged_out_duration"));
				preparedStatement.setInt(20, result.getInt("calls_aband_after_threshold"));
				preparedStatement.setInt(21, result.getInt("calls_ans_after_threshold"));
				preparedStatement.setInt(22, result.getInt("coached"));
				preparedStatement.setLong(23, result.getLong("coached_duration"));
				preparedStatement.setInt(24, result.getInt("coaching"));
				preparedStatement.setLong(25, result.getLong("coaching_duration"));
				preparedStatement.setLong(26, result.getLong("comp_abandon_time_duration"));
				preparedStatement.setLong(27, result.getLong("comp_active_time_duration"));
				preparedStatement.setInt(28, result.getInt("comp_acw"));
				preparedStatement.setInt(29, result.getInt("comp_acw_extended"));
				preparedStatement.setInt(30, result.getInt("comp_ans_after_threshold"));
				preparedStatement.setInt(31, result.getInt("comp_answered"));
				preparedStatement.setInt(32, result.getInt("comp_barged_in"));
				preparedStatement.setLong(33, result.getLong("comp_barged_in_duration"));
				preparedStatement.setInt(34, result.getInt("comp_barged_out"));
				preparedStatement.setLong(35, result.getLong("comp_barged_out_duration"));
				preparedStatement.setInt(36, result.getInt("comp_coached"));
				preparedStatement.setLong(37, result.getLong("comp_coached_duration"));
				preparedStatement.setInt(38, result.getInt("comp_coaching"));
				preparedStatement.setLong(39, result.getLong("comp_coaching_duration"));
				preparedStatement.setInt(40, result.getInt("comp_conferenced"));
				preparedStatement.setInt(41, result.getInt("comp_conferenced_initiated"));
				preparedStatement.setLong(42, result.getLong("comp_consult_duration"));
				preparedStatement.setLong(43, result.getLong("comp_consulted_duration"));
				preparedStatement.setLong(44, result.getLong("comp_consulting_duration"));
				preparedStatement.setInt(45, result.getInt("comp_consults"));
				preparedStatement.setInt(46, result.getInt("comp_consults_accepted"));
				preparedStatement.setInt(47, result.getInt("comp_consults_accept_from_agnt"));
				preparedStatement.setInt(48, result.getInt("comp_consults_accept_from_serv"));
				preparedStatement.setInt(49, result.getInt("comp_consults_initiated"));
				preparedStatement.setInt(50, result.getInt("comp_consults_init_to_agent"));
				preparedStatement.setInt(51, result.getInt("comp_consults_init_to_service"));
				preparedStatement.setLong(52, result.getLong("comp_hold_duration"));
				preparedStatement.setInt(53, result.getInt("comp_holds"));
				preparedStatement.setInt(54, result.getInt("completed"));
				preparedStatement.setInt(55, result.getInt("comp_long_acw"));
				preparedStatement.setInt(56, result.getInt("comp_long_holds"));
				preparedStatement.setInt(57, result.getInt("comp_observed"));
				preparedStatement.setLong(58, result.getLong("comp_observed_duration"));
				preparedStatement.setInt(59, result.getInt("comp_observing"));
				preparedStatement.setLong(60, result.getLong("comp_observing_duration"));
				preparedStatement.setInt(61, result.getInt("comp_offered"));
				preparedStatement.setLong(62, result.getLong("comp_ring_time_duration"));
				preparedStatement.setInt(63, result.getInt("comp_short_acw"));
				preparedStatement.setInt(64, result.getInt("comp_trans_accept_from_agent"));
				preparedStatement.setInt(65, result.getInt("comp_trans_accept_from_service"));
				preparedStatement.setInt(66, result.getInt("comp_transferred"));
				preparedStatement.setInt(67, result.getInt("comp_transferred_initiated"));
				preparedStatement.setInt(68, result.getInt("comp_transferred_to_agent"));
				preparedStatement.setInt(69, result.getInt("comp_transferred_to_service"));
				preparedStatement.setInt(70, result.getInt("comp_trans_initiate_to_agent"));
				preparedStatement.setInt(71, result.getInt("comp_trans_initiate_to_service"));
				preparedStatement.setLong(72, result.getLong("comp_wait_time"));
				preparedStatement.setInt(73, result.getInt("conferenced"));
				preparedStatement.setInt(74, result.getInt("conferenced_accepted"));
				preparedStatement.setInt(75, result.getInt("conferenced_accepted_from_agent"));
				preparedStatement.setInt(76, result.getInt("conferenced_accepted_from_service"));
				preparedStatement.setInt(77, result.getInt("conferenced_initiated"));
				preparedStatement.setInt(78, result.getInt("conferenced_initiate_to_agent"));
				preparedStatement.setInt(79, result.getInt("conferenced_initiate_to_service"));
				preparedStatement.setLong(80, result.getLong("consult_duration"));
				preparedStatement.setLong(81, result.getLong("consulted_duration"));
				preparedStatement.setLong(82, result.getLong("consulting_duration"));
				preparedStatement.setInt(83, result.getInt("consults"));
				preparedStatement.setInt(84, result.getInt("consults_accepted"));
				preparedStatement.setInt(85, result.getInt("consults_accept_from_agent"));
				preparedStatement.setInt(86, result.getInt("consults_accept_from_service"));
				preparedStatement.setInt(87, result.getInt("consults_initiated"));
				preparedStatement.setInt(88, result.getInt("consults_initiate_to_agent"));
				preparedStatement.setInt(89, result.getInt("consults_initiate_to_service"));
				preparedStatement.setInt(90, result.getInt("deferred_contacts"));
				preparedStatement.setInt(91, result.getInt("email_forward"));
				preparedStatement.setLong(92, result.getLong("hold_duration"));
				preparedStatement.setInt(93, result.getInt("holds"));
				preparedStatement.setInt(94, result.getInt("long_acw"));
				preparedStatement.setInt(95, result.getInt("long_engagements"));
				preparedStatement.setInt(96, result.getInt("long_holds"));
				preparedStatement.setInt(97, result.getInt("max_staffed"));
				preparedStatement.setLong(98, result.getLong("max_wait_duration"));
				preparedStatement.setInt(99, result.getInt("not_answered"));
				preparedStatement.setInt(100, result.getInt("observed"));
				preparedStatement.setLong(101, result.getLong("observed_duration"));
				preparedStatement.setInt(102, result.getInt("observing"));
				preparedStatement.setLong(103, result.getLong("observing_duration"));
				preparedStatement.setInt(104, result.getInt("offered"));
				preparedStatement.setInt(105, result.getInt("repeated_deferrals"));
				preparedStatement.setInt(106, result.getInt("replied"));
				preparedStatement.setLong(107, result.getLong("ring_time_duration"));
				preparedStatement.setInt(108, result.getInt("short_acw"));
				preparedStatement.setInt(109, result.getInt("short_engagements"));
				preparedStatement.setInt(110, result.getInt("super_defer_completed"));
				preparedStatement.setLong(111, result.getLong("super_defer_transferred"));
				preparedStatement.setLong(112, result.getLong("tot_duration"));
				preparedStatement.setInt(113, result.getInt("trans_accept_from_agent"));
				preparedStatement.setInt(114, result.getInt("trans_accept_from_service"));
				preparedStatement.setInt(115, result.getInt("transferred"));
				preparedStatement.setInt(116, result.getInt("transferred_accepted"));
				preparedStatement.setInt(117, result.getInt("transferred_initiated"));
				preparedStatement.setInt(118, result.getInt("transferred_to_agent"));
				preparedStatement.setInt(119, result.getInt("transferred_to_service"));
				preparedStatement.setInt(120, result.getInt("trans_initiate_to_agent"));
				preparedStatement.setInt(121, result.getInt("trans_initiate_to_service"));
				preparedStatement.setLong(122, result.getLong("wait_time"));

				preparedStatement.setLong(123, result.getLong("approval_active_time_duration"));
				preparedStatement.setInt(124, result.getInt("approval_answered"));
				preparedStatement.setInt(125, result.getInt("approval_requeued"));
				preparedStatement.setInt(126, result.getInt("approval_review_approved"));
				preparedStatement.setInt(127, result.getInt("approval_review_rejected"));
				preparedStatement.setLong(128, result.getLong("comp_approval_active_time_duration"));
				preparedStatement.setInt(129, result.getInt("comp_approval_answered"));
				preparedStatement.setLong(130, result.getLong("comp_rework_active_time_duration"));
				preparedStatement.setInt(131, result.getInt("comp_rework_answered"));
				preparedStatement.setLong(132, result.getLong("rework_active_time_duration"));
				preparedStatement.setInt(133, result.getInt("rework_answered"));
				preparedStatement.setInt(134, result.getInt("rework_closed"));
				preparedStatement.setInt(135, result.getInt("rework_replied"));
				preparedStatement.setInt(136, result.getInt("sent_for_approval"));
				preparedStatement.setInt(137, result.getInt("work_approved"));
				preparedStatement.setInt(138, result.getInt("work_rejected"));

				preparedStatement.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static void loadROUTING_SERVICE_BY_AGENT_INTERVAL_DATA(Connection connection, Connection mssqlconnection)
			throws Exception {
		try {
			// Statement delete_stmt=mssqlconnection.createStatement();
			// System.out.println("\n"+new Timestamp(new Date().getTime()) + " : Deleting
			// routing_service_by_agent_interval records on the same interval delete_stmt :
			// " + "DELETE FROM routing_service_by_agent_interval WHERE
			// interval_start_timestamp >= '"+START_TIME+"' and interval_start_timestamp <
			// '"+END_TIME+"'");
			// delete_stmt.executeUpdate("DELETE FROM routing_service_by_agent_interval
			// WHERE interval_start_timestamp >= '"+START_TIME+"' and
			// interval_start_timestamp < '"+END_TIME+"'");

			String selectQuery = "SELECT etl_ticket_id,TO_CHAR(interval_start_timestamp, 'YYYY-MM-DD HH24:MI:SS.MS') AS interval_start_timestamp,TO_CHAR(last_changed, 'YYYY-MM-DD HH24:MI:SS.MS') AS last_changed,utc_quarter_hour_sk  ,agent_sk  ,routing_service_sk  ,abandoned ,active_time_duration ,acw ,acw_duration ,acw_extended ,alert_duration ,answered ,barged_in ,barged_in_duration ,barged_out ,barged_out_duration ,blended_active ,blended_active_duration ,coached ,coached_duration ,coaching ,coaching_duration ,comp_active_time_duration ,comp_acw ,comp_acw_extended ,comp_alert_duration ,comp_answered ,comp_barged_in ,comp_barged_in_duration ,comp_barged_out ,comp_barged_out_duration ,comp_blended_active ,comp_blended_active_duration ,comp_coached ,comp_coached_duration ,comp_coaching ,comp_coaching_duration ,comp_conferenced ,comp_conferenced_initiated ,comp_consult_duration ,comp_consulted_duration ,comp_consulting_duration ,comp_consults ,comp_consults_accepted ,comp_consults_accept_from_agnt ,comp_consults_accept_from_serv ,comp_consults_initiated ,comp_consults_init_to_agent ,comp_consults_init_to_service ,comp_hold_duration ,comp_holds ,completed ,comp_long_acw ,comp_long_holds ,comp_observed ,comp_observed_duration ,comp_observing ,comp_observing_duration ,comp_offered ,comp_short_acw ,comp_trans_accept_from_agent ,comp_trans_accept_from_service ,comp_transferred ,comp_transferred_initiated ,comp_transferred_to_agent ,comp_transferred_to_service ,comp_trans_initiate_to_agent ,comp_trans_initiate_to_service ,conferenced ,conferenced_accepted ,conferenced_accepted_from_agent ,conferenced_accepted_from_service ,conferenced_initiated ,conferenced_initiate_to_agent ,conferenced_initiate_to_service ,consult_duration ,consulted_duration ,consulting_duration ,consults ,consults_accepted ,consults_accept_from_agent ,consults_accept_from_service ,consults_initiated ,consults_initiate_to_agent ,consults_initiate_to_service ,deferred_contacts ,disconnects_from_hold ,email_forward ,hold_duration ,holds ,long_acw ,long_engagements ,long_holds ,not_answered ,observed ,observed_duration ,observing ,observing_duration ,offered ,repeated_deferrals ,replied ,short_acw ,short_engagements ,super_defer_completed ,super_defer_transferred ,trans_accept_from_agent ,trans_accept_from_service ,transferred ,transferred_accepted ,transferred_initiated ,transferred_to_agent ,transferred_to_service ,trans_initiate_to_agent ,trans_initiate_to_service ,approval_active_time_duration , approval_answered , approval_requeued , approval_review_approved , approval_review_rejected , comp_approval_active_time_duration , comp_approval_answered , comp_rework_active_time_duration , comp_rework_answered , rework_active_time_duration , rework_answered , rework_closed , rework_replied , sent_for_approval , work_approved , work_rejected from fact.routing_service_by_agent_interval where interval_start_timestamp >= TO_TIMESTAMP('"
					+ START_TIME + "', 'YYYY-MM-DD HH24:MI:SS.MS') AND interval_start_timestamp < TO_TIMESTAMP('"
					+ END_TIME + "', 'YYYY-MM-DD HH24:MI:SS.MS');";

			Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery(selectQuery);

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : "
					+ "loadROUTING_SERVICE_BY_AGENT_INTERVAL_DATA selectQuery = " + selectQuery);

			String insertQuery = "INSERT INTO routing_service_by_agent_interval (etl_ticket_id,interval_start_timestamp,last_changed,utc_quarter_hour_sk,agent_sk,routing_service_sk,abandoned,active_time_duration,acw,acw_duration,acw_extended,alert_duration,answered,barged_in,barged_in_duration,barged_out,barged_out_duration,blended_active,blended_active_duration,coached,coached_duration,coaching,coaching_duration,comp_active_time_duration,comp_acw,comp_acw_extended,comp_alert_duration,comp_answered,comp_barged_in,comp_barged_in_duration,comp_barged_out,comp_barged_out_duration,comp_blended_active,comp_blended_active_duration,comp_coached,comp_coached_duration,comp_coaching,comp_coaching_duration,comp_conferenced,comp_conferenced_initiated,comp_consult_duration,comp_consulted_duration,comp_consulting_duration,comp_consults,comp_consults_accepted,comp_consults_accept_from_agnt,comp_consults_accept_from_serv,comp_consults_initiated,comp_consults_init_to_agent,comp_consults_init_to_service,comp_hold_duration,comp_holds,completed,comp_long_acw,comp_long_holds,comp_observed,comp_observed_duration,comp_observing,comp_observing_duration,comp_offered,comp_short_acw,comp_trans_accept_from_agent,comp_trans_accept_from_service,comp_transferred,comp_transferred_initiated,comp_transferred_to_agent,comp_transferred_to_service,comp_trans_initiate_to_agent,comp_trans_initiate_to_service,conferenced,conferenced_accepted,conferenced_accepted_from_agent,conferenced_accepted_from_service,conferenced_initiated,conferenced_initiate_to_agent,conferenced_initiate_to_service,consult_duration,consulted_duration,consulting_duration,consults,consults_accepted,consults_accept_from_agent,consults_accept_from_service,consults_initiated,consults_initiate_to_agent,consults_initiate_to_service,deferred_contacts,disconnects_from_hold,email_forward,hold_duration,holds,long_acw,long_engagements,long_holds,not_answered,observed,observed_duration,observing,observing_duration,offered,repeated_deferrals,replied,short_acw,short_engagements,super_defer_completed,super_defer_transferred,trans_accept_from_agent,trans_accept_from_service,transferred,transferred_accepted,transferred_initiated,transferred_to_agent,transferred_to_service,trans_initiate_to_agent,trans_initiate_to_service, approval_active_time_duration , approval_answered , approval_requeued , approval_review_approved , approval_review_rejected , comp_approval_active_time_duration , comp_approval_answered , comp_rework_active_time_duration , comp_rework_answered , rework_active_time_duration , rework_answered , rework_closed , rework_replied , sent_for_approval , work_approved , work_rejected) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : "
					+ "loadROUTING_SERVICE_BY_AGENT_INTERVAL_DATA insertQuery = " + insertQuery);

			PreparedStatement preparedStatement = mssqlconnection.prepareStatement(insertQuery);
			while (result.next()) {
				preparedStatement.setLong(1, result.getLong("etl_ticket_id"));
				preparedStatement.setString(2, result.getString("interval_start_timestamp"));
				preparedStatement.setString(3, result.getString("last_changed"));
				preparedStatement.setLong(4, result.getLong("utc_quarter_hour_sk"));
				preparedStatement.setInt(5, result.getInt("agent_sk"));
				preparedStatement.setInt(6, result.getInt("routing_service_sk"));
				preparedStatement.setInt(7, result.getInt("abandoned"));
				preparedStatement.setLong(8, result.getLong("active_time_duration"));
				preparedStatement.setInt(9, result.getInt("acw"));
				preparedStatement.setLong(10, result.getLong("acw_duration"));
				preparedStatement.setInt(11, result.getInt("acw_extended"));
				preparedStatement.setLong(12, result.getLong("alert_duration"));
				preparedStatement.setInt(13, result.getInt("answered"));
				preparedStatement.setInt(14, result.getInt("barged_in"));
				preparedStatement.setLong(15, result.getLong("barged_in_duration"));
				preparedStatement.setInt(16, result.getInt("barged_out"));
				preparedStatement.setLong(17, result.getLong("barged_out_duration"));
				preparedStatement.setInt(18, result.getInt("blended_active"));
				preparedStatement.setLong(19, result.getLong("blended_active_duration"));
				preparedStatement.setInt(20, result.getInt("coached"));
				preparedStatement.setLong(21, result.getLong("coached_duration"));
				preparedStatement.setInt(22, result.getInt("coaching"));
				preparedStatement.setLong(23, result.getLong("coaching_duration"));
				preparedStatement.setLong(24, result.getLong("comp_active_time_duration"));
				preparedStatement.setInt(25, result.getInt("comp_acw"));
				preparedStatement.setInt(26, result.getInt("comp_acw_extended"));
				preparedStatement.setLong(27, result.getLong("comp_alert_duration"));
				preparedStatement.setInt(28, result.getInt("comp_answered"));
				preparedStatement.setInt(29, result.getInt("comp_barged_in"));
				preparedStatement.setLong(30, result.getLong("comp_barged_in_duration"));
				preparedStatement.setInt(31, result.getInt("comp_barged_out"));
				preparedStatement.setLong(32, result.getLong("comp_barged_out_duration"));
				preparedStatement.setInt(33, result.getInt("comp_blended_active"));
				preparedStatement.setLong(34, result.getLong("comp_blended_active_duration"));
				preparedStatement.setInt(35, result.getInt("comp_coached"));
				preparedStatement.setLong(36, result.getLong("comp_coached_duration"));
				preparedStatement.setInt(37, result.getInt("comp_coaching"));
				preparedStatement.setLong(38, result.getLong("comp_coaching_duration"));
				preparedStatement.setInt(39, result.getInt("comp_conferenced"));
				preparedStatement.setInt(40, result.getInt("comp_conferenced_initiated"));
				preparedStatement.setLong(41, result.getLong("comp_consult_duration"));
				preparedStatement.setLong(42, result.getLong("comp_consulted_duration"));
				preparedStatement.setLong(43, result.getLong("comp_consulting_duration"));
				preparedStatement.setInt(44, result.getInt("comp_consults"));
				preparedStatement.setInt(45, result.getInt("comp_consults_accepted"));
				preparedStatement.setInt(46, result.getInt("comp_consults_accept_from_agnt"));
				preparedStatement.setInt(47, result.getInt("comp_consults_accept_from_serv"));
				preparedStatement.setInt(48, result.getInt("comp_consults_initiated"));
				preparedStatement.setInt(49, result.getInt("comp_consults_init_to_agent"));
				preparedStatement.setInt(50, result.getInt("comp_consults_init_to_service"));
				preparedStatement.setLong(51, result.getLong("comp_hold_duration"));
				preparedStatement.setInt(52, result.getInt("comp_holds"));
				preparedStatement.setInt(53, result.getInt("completed"));
				preparedStatement.setInt(54, result.getInt("comp_long_acw"));
				preparedStatement.setInt(55, result.getInt("comp_long_holds"));
				preparedStatement.setInt(56, result.getInt("comp_observed"));
				preparedStatement.setLong(57, result.getLong("comp_observed_duration"));
				preparedStatement.setInt(58, result.getInt("comp_observing"));
				preparedStatement.setLong(59, result.getLong("comp_observing_duration"));
				preparedStatement.setInt(60, result.getInt("comp_offered"));
				preparedStatement.setInt(61, result.getInt("comp_short_acw"));
				preparedStatement.setInt(62, result.getInt("comp_trans_accept_from_agent"));
				preparedStatement.setInt(63, result.getInt("comp_trans_accept_from_service"));
				preparedStatement.setInt(64, result.getInt("comp_transferred"));
				preparedStatement.setInt(65, result.getInt("comp_transferred_initiated"));
				preparedStatement.setInt(66, result.getInt("comp_transferred_to_agent"));
				preparedStatement.setInt(67, result.getInt("comp_transferred_to_service"));
				preparedStatement.setInt(68, result.getInt("comp_trans_initiate_to_agent"));
				preparedStatement.setInt(69, result.getInt("comp_trans_initiate_to_service"));
				preparedStatement.setInt(70, result.getInt("conferenced"));
				preparedStatement.setInt(71, result.getInt("conferenced_accepted"));
				preparedStatement.setInt(72, result.getInt("conferenced_accepted_from_agent"));
				preparedStatement.setInt(73, result.getInt("conferenced_accepted_from_service"));
				preparedStatement.setInt(74, result.getInt("conferenced_initiated"));
				preparedStatement.setInt(75, result.getInt("conferenced_initiate_to_agent"));
				preparedStatement.setInt(76, result.getInt("conferenced_initiate_to_service"));
				preparedStatement.setLong(77, result.getLong("consult_duration"));
				preparedStatement.setLong(78, result.getLong("consulted_duration"));
				preparedStatement.setLong(79, result.getLong("consulting_duration"));
				preparedStatement.setInt(80, result.getInt("consults"));
				preparedStatement.setInt(81, result.getInt("consults_accepted"));
				preparedStatement.setInt(82, result.getInt("consults_accept_from_agent"));
				preparedStatement.setInt(83, result.getInt("consults_accept_from_service"));
				preparedStatement.setInt(84, result.getInt("consults_initiated"));
				preparedStatement.setInt(85, result.getInt("consults_initiate_to_agent"));
				preparedStatement.setInt(86, result.getInt("consults_initiate_to_service"));
				preparedStatement.setInt(87, result.getInt("deferred_contacts"));
				preparedStatement.setInt(88, result.getInt("disconnects_from_hold"));
				preparedStatement.setInt(89, result.getInt("email_forward"));
				preparedStatement.setLong(90, result.getLong("hold_duration"));
				preparedStatement.setInt(91, result.getInt("holds"));
				preparedStatement.setInt(92, result.getInt("long_acw"));
				preparedStatement.setInt(93, result.getInt("long_engagements"));
				preparedStatement.setInt(94, result.getInt("long_holds"));
				preparedStatement.setInt(95, result.getInt("not_answered"));
				preparedStatement.setInt(96, result.getInt("observed"));
				preparedStatement.setLong(97, result.getLong("observed_duration"));
				preparedStatement.setInt(98, result.getInt("observing"));
				preparedStatement.setLong(99, result.getLong("observing_duration"));
				preparedStatement.setInt(100, result.getInt("offered"));
				preparedStatement.setInt(101, result.getInt("repeated_deferrals"));
				preparedStatement.setInt(102, result.getInt("replied"));
				preparedStatement.setInt(103, result.getInt("short_acw"));
				preparedStatement.setInt(104, result.getInt("short_engagements"));
				preparedStatement.setInt(105, result.getInt("super_defer_completed"));
				preparedStatement.setInt(106, result.getInt("super_defer_transferred"));
				preparedStatement.setInt(107, result.getInt("trans_accept_from_agent"));
				preparedStatement.setInt(108, result.getInt("trans_accept_from_service"));
				preparedStatement.setInt(109, result.getInt("transferred"));
				preparedStatement.setInt(110, result.getInt("transferred_accepted"));
				preparedStatement.setInt(111, result.getInt("transferred_initiated"));
				preparedStatement.setInt(112, result.getInt("transferred_to_agent"));
				preparedStatement.setInt(113, result.getInt("transferred_to_service"));
				preparedStatement.setInt(114, result.getInt("trans_initiate_to_agent"));
				preparedStatement.setInt(115, result.getInt("trans_initiate_to_service"));
				preparedStatement.setLong(116, result.getLong("approval_active_time_duration"));
				preparedStatement.setInt(117, result.getInt("approval_answered"));
				preparedStatement.setInt(118, result.getInt("approval_requeued"));
				preparedStatement.setInt(119, result.getInt("approval_review_approved"));
				preparedStatement.setInt(120, result.getInt("approval_review_rejected"));
				preparedStatement.setLong(121, result.getLong("comp_approval_active_time_duration"));
				preparedStatement.setInt(122, result.getInt("comp_approval_answered"));
				preparedStatement.setLong(123, result.getLong("comp_rework_active_time_duration"));
				preparedStatement.setInt(124, result.getInt("comp_rework_answered"));
				preparedStatement.setLong(125, result.getLong("rework_active_time_duration"));
				preparedStatement.setInt(126, result.getInt("rework_answered"));
				preparedStatement.setInt(127, result.getInt("rework_closed"));
				preparedStatement.setInt(128, result.getInt("rework_replied"));
				preparedStatement.setInt(129, result.getInt("sent_for_approval"));
				preparedStatement.setInt(130, result.getInt("work_approved"));
				preparedStatement.setInt(131, result.getInt("work_rejected"));
				preparedStatement.executeUpdate();
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static void updateAllTrunckBusy(Connection alltrunckcon, Connection mssqlcon) throws Exception {
		try {
			ResultSet result;

			String selectQuery = "SELECT CASE WHEN MAX(PEAK) >= 100 THEN 100 ELSE 0 END AS MAXPORTUTIL FROM PUBLIC.VPPERFORMANCE WHERE TIME >= TO_TIMESTAMP('"
					+ START_TIME + "','YYYY-MM-DD HH24:MI:SS.MS') AND TIME < TO_TIMESTAMP('" + END_TIME
					+ "','YYYY-MM-DD HH24:MI:SS.MS') AND TIME IS NOT NULL;";

			System.out.println("\n" + new Timestamp(new Date().getTime()) + " : "
					+ "updateINBOUND_CALLS => selectQuery: " + selectQuery);

			Statement statement = alltrunckcon.createStatement();
			result = statement.executeQuery(selectQuery);

			String updateQuery = "";
			String updateQuerysec = "";

			Statement preparedStatement = mssqlcon.createStatement();

			while (result.next()) {
				updateQuery = "UPDATE INBOUND_CALLS SET ALL_TRUNKS_BUSY =" + result.getLong("MAXPORTUTIL")
						+ " where START_INTERVAL_TIME = CONVERT(DATETIME,'" + START_TIME
						+ "',121) and END_INTERVAL_TIME = CONVERT(DATETIME,'" + END_TIME + "',121);";

				System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "updateQuery : " + updateQuery);

				preparedStatement.executeUpdate(updateQuery);

				updateQuerysec = "UPDATE INBOUND_CALLS_DETAILED_REPORT SET ALL_TRUNKS_BUSY ="
						+ result.getLong("MAXPORTUTIL") + " where START_TIME = CONVERT(DATETIME,'" + START_TIME
						+ "',121) and END_TIME = CONVERT(DATETIME,'" + END_TIME + "',121);";

				System.out.println("\n" + new Timestamp(new Date().getTime()) + " : " + "updateQuerysec : " + updateQuerysec);

				preparedStatement.executeUpdate(updateQuerysec);

				// System.out.println("COMPLETED ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// throw e;
		}
	}

	public static void main(String args[]) throws Exception {

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new java.util.Date());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		// Here you set to your timezone
		sdf.setTimeZone(TimeZone.getDefault());

		System.out.println("********* STARTED@ ********* " + sdf.format(calendar.getTime()));

		try {
			FileInputStream fis = new FileInputStream("E:/CustomReporting/scheduler/config.properties");

			Properties prop = new Properties();
			prop.load(fis);

			// String db_name = "db.mssql";
			String db_name = "db.postgresql";

			String driver = prop.getProperty(db_name + ".driver");
			String url = prop.getProperty(db_name + ".connection.url");
			String user = prop.getProperty(db_name + ".user");
			String password = prop.getProperty(db_name + ".password");

			System.out.println("Driver:" + driver + ", url:" + url + ", user:" + user + ", password:" + password);
			Class.forName(driver);
			Connection con = DriverManager.getConnection(url, user, password);

			db_name = "db.mssql.src";
			driver = prop.getProperty(db_name + ".driver");
			url = prop.getProperty(db_name + ".connection.url");
			user = prop.getProperty(db_name + ".user");
			password = prop.getProperty(db_name + ".password");

			System.out.println("Driver:" + driver + ", url:" + url + ", user:" + user + ", password:" + password);
			Class.forName(driver);
			Connection src_mssqlcon = DriverManager.getConnection(url, user, password);

			db_name = "db.mssql";
			driver = prop.getProperty(db_name + ".driver");
			url = prop.getProperty(db_name + ".connection.url");
			user = prop.getProperty(db_name + ".user");
			password = prop.getProperty(db_name + ".password");

			System.out.println("Driver:" + driver + ", url:" + url + ", user:" + user + ", password:" + password);
			Class.forName(driver);
			Connection mssqlcon = DriverManager.getConnection(url, user, password);

			// getReportIntervals(mssqlcon, "DATA_DUMP_START_TIME");
			System.out.println("Start: " + START_TIME + " - " + END_TIME);

			// cleanupTables(mssqlcon,null);
			// loadDIM_ROUTING_SERVICES(con, mssqlcon);
			// loadDIM_AGENTS(con, mssqlcon);
			// setReportIntervals(mssqlcon,"");

			con.close();
			mssqlcon.close();
			src_mssqlcon.close();
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("Exception occurred while connecting to DB. " + e);
			e.printStackTrace();
		}
		calendar.setTime(new java.util.Date());
		System.out.println("********* END@ *********  " + sdf.format(calendar.getTime()));
	}
}