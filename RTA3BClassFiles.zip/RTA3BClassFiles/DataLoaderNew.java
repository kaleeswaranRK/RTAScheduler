
//javac -classpath E:\CustomReporting\scheduler\libs\mssql-jdbc-8.4.1.jre8.jar;E:\CustomReporting\scheduler\libs\postgresql-42.2.18.jar;. DataLoaderNew.java
//java -classpath E:\CustomReporting\scheduler\libs\mssql-jdbc-8.4.1.jre8.jar;E:\CustomReporting\scheduler\libs\postgresql-42.2.18.jar;. DataLoaderNew >> E:\CustomReporting\scheduler\logs\DataLoaderNew_%date:~10%%date:~4,2%%date:~7,2%.log 2>&1

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class DataLoaderNew {

	static String START_TIME = "2021-02-08 00:00:00.000";
	static String END_TIME = "2021-02-09 00:00:00.000";
	// static Integer runnableInterval = 0;

	// public static Integer getRunnableIntervalCount(Connection con, String
	// startTimeName, String endTimeName) throws Exception{
	// Integer runnableInterval = 0;
	// Statement stmt = con.createStatement();
	// String sql = "";
	// ResultSet rs = null;
	// String startTime = "";
	// String endTime = "";
	// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	// if(startTimeName.equalsIgnoreCase("DATA_DUMP_START_TIME"))
	// {
	// sql = "SELECT CONVERT(VARCHAR(50), CONVERT(DATETIME, PARAM_VALUE, 121), 121)
	// AS START_TIME FROM CONFIG_PARAMS WHERE PARAM_NAME = '"+startTimeName+"'";
	//
	// System.out.println(currenttimestamp()+ "getRunnableIntervalCount =>
	// startTimeName : " + startTimeName + " => paramName => " + endTimeName + ".
	// Query: " + sql);
	// rs = stmt.executeQuery(sql);
	//
	// while(rs.next()) {
	// startTime = rs.getString(1);
	// }
	// Date ct = new Date();
	// endTime = sdf.format(ct);
	//// Date st = sdf.parse(startTime);
	////
	//// System.out.println(currenttimestamp() +" : Start Time : "+ sdf.format(st));
	//// System.out.println(currenttimestamp() +" : Current Time : "+
	// sdf.format(ct));
	////
	//// System.out.println(currenttimestamp() +" : Total Minutes Difference :
	// "+(((ct.getTime() - st.getTime()) / 1000) /60));
	////
	//// long totalRunnableInterval = ((((ct.getTime() - st.getTime()) / 1000) /60)
	// / 30) - 2;
	//// runnableInterval = (int) totalRunnableInterval;
	//// System.out.println(currenttimestamp() +" : Total Runnable Interval : "+
	// runnableInterval);
	////
	//// rs.close();
	// } else {
	//// String sql = "SELECT CONVERT(VARCHAR(50), CONVERT(DATETIME, PARAM_VALUE,
	// 121), 121) AS START_TIME FROM CONFIG_PARAMS WHERE PARAM_NAME =
	// '"+startTimeName+"'";
	//// String sql = "SELECT CONVERT(VARCHAR(50), CONVERT(DATETIME, PARAM_VALUE,
	// 121), 121) AS START_TIME FROM CONFIG_PARAMS WHERE PARAM_NAME IN
	// ('"+startTimeName+"','"+endTimeName+"') order by case PARAM_NAME when
	// '"+startTimeName+"' then 1 when '"+endTimeName+"' then 2 else 10 end";
	// sql = "SELECT CONVERT(VARCHAR(50), CONVERT(DATETIME, PARAM_VALUE, 121), 121)
	// AS START_TIME, (SELECT CONVERT(VARCHAR(50), CONVERT(DATETIME, PARAM_VALUE,
	// 121), 121) AS END_TIME FROM CONFIG_PARAMS WHERE PARAM_NAME =
	// '"+endTimeName+"') as end_time FROM CONFIG_PARAMS WHERE PARAM_NAME =
	// '"+startTimeName+"'";
	// System.out.println(currenttimestamp()+ "getRunnableIntervalCount =>
	// startTimeName : " + startTimeName + " => endTimeName => " + endTimeName + ".
	// Query: " + sql);
	// rs = stmt.executeQuery(sql);
	//
	//
	// while(rs.next()) {
	// startTime = rs.getString(1);
	// endTime = rs.getString(2);
	// }
	//
	// }
	//// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	// Date st = sdf.parse(startTime);
	// Date et = sdf.parse(endTime);
	// System.out.println(currenttimestamp() +" : Start Time : "+ sdf.format(st));
	// System.out.println(currenttimestamp() +" : End Time : "+ sdf.format(et));
	//
	// System.out.println(currenttimestamp() +" : Total Minutes Difference :
	// "+(((et.getTime() - st.getTime()) / 1000) /60));
	//
	// long totalRunnableInterval = ((((et.getTime() - st.getTime()) / 1000) /60) /
	// 30) - 2;
	// runnableInterval = (int) totalRunnableInterval;
	// System.out.println(currenttimestamp() +" : Total Runnable Interval : "+
	// runnableInterval);
	// rs.close();
	// return runnableInterval;
	//
	//
	// }

	public static void getReportIntervals(Connection con, String reportName, String paramName) throws Exception {
		Statement stmt = con.createStatement();
		String sql = "SELECT CONVERT(VARCHAR(50), CONVERT(DATETIME, PARAM_VALUE, 121), 121) AS START_TIME, CONVERT(VARCHAR(50), (DATEADD(MINUTE, CAST((SELECT PARAM_VALUE FROM CONFIG_PARAMS WHERE PARAM_NAME = 'TIMEINTERVAL_IN_MINS') AS INT), CONVERT(DATETIME, PARAM_VALUE, 121))), 121) AS END_TIME FROM CONFIG_PARAMS WHERE PARAM_NAME = 'DATA_DUMP_START_TIME'";

		System.out.println(currenttimestamp() + "getReportIntervals => reportName: " + reportName + " => paramName => "
				+ paramName + ". Query: " + sql);
		ResultSet rs = stmt.executeQuery(sql);

		while (rs.next()) {
			START_TIME = rs.getString(1);
			END_TIME = rs.getString(2);
		}
		rs.close();

		System.out.println(currenttimestamp() + "START_TIME:" + START_TIME + ", END_TIME:" + END_TIME);
	}

	public static String currenttimestamp() {
		Timestamp timestamp = new Timestamp(new Date().getTime());
		return timestamp.toString() + " : ";
	}

	public static void setReportIntervals(Connection con, String report_name) throws Exception {
		Statement stmt = con.createStatement();

		String sql = "UPDATE CONFIG_PARAMS SET PARAM_VALUE = '" + END_TIME
				+ "' WHERE PARAM_NAME = 'DATA_DUMP_START_TIME'";

		System.out.println(currenttimestamp() + "setReportIntervals: " + sql);
		stmt.executeUpdate(sql);

	}

	// run method added with CBA data base connection as input
	public static void run(Connection con, Connection cbacon, Connection mssqlcon, int runnableInterval) {
		System.out.println("Total Runnable Intervals : " + runnableInterval);
		try {
			if (runnableInterval >= 1) {
				for (int i = 1; i <= runnableInterval; i++) {
					System.out.println(currenttimestamp() + "********* Interval Started ********* " + i);
					getReportIntervals(mssqlcon, "All", "");

					CustomDataDump.START_TIME = START_TIME;
					CustomDataDump.END_TIME = END_TIME;

//					try {
//						// ReportGenerator.prepareReport(mssqlcon, "[REPORT_TABLE_DATA_DELETE_PRC]",
//						// ",SOURCE=SCHEDULER");
//					} catch (Exception e) {
//						System.out.println(currenttimestamp()
//								+ "Exception occured while preparing Report for REPORT_TABLE_DATA_DELETE_PRC. " + e);
//						e.printStackTrace();
//						// throw new Exception();
//					}
//
					Map<String, Boolean> status = new HashMap<String, Boolean>();
//					try {
//						CustomDataDump.cleanupTables(mssqlcon, "DIM_ROUTING_SERVICES");
//						CustomDataDump.loadDIM_ROUTING_SERVICES(con, mssqlcon);
//						status.put("DIM_ROUTING_SERVICES", true);
//
//					} catch (Exception e) {
//						System.out.println(
//								currenttimestamp() + "Exception occured while Data Dump : DIM_ROUTING_SERVICES. " + e);
//						e.printStackTrace();
//					}
//
//					try {
//						CustomDataDump.cleanupTables(mssqlcon, "DIM_AGENTS");
//						CustomDataDump.loadDIM_AGENTS(con, mssqlcon);
//						status.put("DIM_AGENTS", true);
//
//					} catch (Exception e) {
//						System.out.println(currenttimestamp() + "Exception occured while Data Dump : DIM_AGENTS. " + e);
//						e.printStackTrace();
//					}
//
//					try {
//						CustomDataDump.cleanupTables(mssqlcon, "DIM_NOT_READY_REASON_CODES");
//						CustomDataDump.loadDIM_NOT_READY_REASON_CODES(con, mssqlcon);
//						status.put("DIM_NOT_READY_REASON_CODES", true);
//
//					} catch (Exception e) {
//						System.out.println(currenttimestamp()
//								+ "Exception occured while Data Dump : DIM_NOT_READY_REASON_CODES. " + e);
//						e.printStackTrace();
//					}
//
//					try {
//						CustomDataDump.loadCDR_CONTACTS(con, mssqlcon);
//						status.put("CDR_CONTACTS", true);
//
//					} catch (Exception e) {
//						System.out
//								.println(currenttimestamp() + "Exception occured while Data Dump : CDR_CONTACTS. " + e);
//						e.printStackTrace();
//					}
//					try {
//						CustomDataDump.loadCDR_SEGMENTS(con, mssqlcon);
//						status.put("CDR_SEGMENTS", true);
//
//					} catch (Exception e) {
//						System.out
//								.println(currenttimestamp() + "Exception occured while Data Dump : CDR_SEGMENTS. " + e);
//						e.printStackTrace();
//						// throw new Exception();
//					}
//
//					try {
//						CustomDataDump.loadAGENT_LOGON(con, mssqlcon);
//						status.put("AGENT_LOGON", true);
//
//					} catch (Exception e) {
//						System.out
//								.println(currenttimestamp() + "Exception occured while Data Dump : AGENT_LOGON. " + e);
//						e.printStackTrace();
//						// throw new Exception();
//					}
//
//					try {
//						CustomDataDump.loadAGENT_BY_NOT_READY_REASON_CODE_INTERVAL(con, mssqlcon);
//						status.put("AGENT_BY_NOT_READY_REASON_CODE_INTERVAL", true);
//
//					} catch (Exception e) {
//						System.out.println(currenttimestamp()
//								+ "Exception occured while Data Dump : AGENT_BY_NOT_READY_REASON_CODE_INTERVAL. " + e);
//						e.printStackTrace();
//						// throw new Exception();
//					}
//
//					try {
//						CustomDataDump.loadAGENT_INTERVAL(con, mssqlcon);
//						status.put("AGENT_INTERVAL", true);
//
//					} catch (Exception e) {
//						System.out.println(
//								currenttimestamp() + "Exception occured while Data Dump : AGENT_INTERVAL. " + e);
//						e.printStackTrace();
//						// throw new Exception();
//					}
//
//					try {
//						CustomDataDump.loadROUTING_SERVICE_INTERVAL_DATA(con, mssqlcon);
//						status.put("ROUTING_SERVICE_INTERVAL", true);
//
//					} catch (Exception e) {
//						System.out.println(currenttimestamp()
//								+ "Exception occured while Data Dump : ROUTING_SERVICE_INTERVAL. " + e);
//						e.printStackTrace();
//						// throw new Exception();
//					}
//
//					try {
//						CustomDataDump.loadROUTING_SERVICE_BY_AGENT_INTERVAL_DATA(con, mssqlcon);
//						status.put("ROUTING_SERVICE_BY_AGENT_INTERVAL", true);
//
//					} catch (Exception e) {
//						System.out.println(currenttimestamp()
//								+ "Exception occured while Data Dump : ROUTING_SERVICE_BY_AGENT_INTERVAL. " + e);
//						e.printStackTrace();
//						// throw new Exception();
//					}
//
//					try {
//						CustomDataDump.updateAGENT_LOGON(con, mssqlcon);
//						status.put("updateAGENT_LOGON", true);
//
//					} catch (Exception e) {
//						System.out.println(
//								currenttimestamp() + "Exception occured while Data Dump : updateAGENT_LOGON. " + e);
//						e.printStackTrace();
//						// throw new Exception();
//					}

					// 2b.loadCallBack and loadCallBackSummary data dump from CBA database added
					try {
						CustomDataDump.loadCallBack(cbacon, mssqlcon);
						status.put("CallBack", true);
					} catch (Exception e) {
						System.out.println(currenttimestamp() + "Exception occured while Data Dump : CallBack. " + e);
						e.printStackTrace();
					}
					try {
						CustomDataDump.loadCallBackSummary(cbacon, mssqlcon);
						status.put("CallBackSummary", true);
					} catch (Exception e) {
						System.out.println(
								currenttimestamp() + "Exception occured while Data Dump : CallBackSummary. " + e);
						e.printStackTrace();
					}

					// 2b.callback and calBackSummary condition added
//					if (status.get("CDR_CONTACTS") && status.get("CDR_SEGMENTS") && status.get("AGENT_LOGON")
//							&& status.get("AGENT_INTERVAL") && status.get("ROUTING_SERVICE_INTERVAL")
//							&& status.get("ROUTING_SERVICE_BY_AGENT_INTERVAL") && status.get("DIM_ROUTING_SERVICES")
//							&& status.get("DIM_AGENTS") && 
					if(status.get("CallBack") && status.get("CallBackSummary")) {
						setReportIntervals(mssqlcon, "DATA_DUMP_START_TIME");
						System.out.println(currenttimestamp() + "Data load completed successfully for the period: "
								+ START_TIME + " - " + END_TIME);

						System.out.println(currenttimestamp() + "Procedure execution starts");

//						int slaReportRC = getRunnableIntervalCount(mssqlcon, "SLA_REPORT", "DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "SLA_REPORT_PRC", ",SOURCE=SCHEDULER", slaReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for the call type SLA_REPORT_PRC. "
//									+ e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//
//						int inboundInfoReportRC = getRunnableIntervalCount(mssqlcon,
//								"INBOUND_INFORMATIONAL_REPORT_START_TIME", "DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "INBOUND_CALL_HISTORY_REPORT_PRC",
//									",SOURCE=SCHEDULER,CALL_TYPE=Informational", inboundInfoReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for the call type INBOUND_CALL_HISTORY_REPORT_PRC => Informational. "
//									+ e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//
//						int inboundTranReportRC = getRunnableIntervalCount(mssqlcon,
//								"INBOUND_TRANSACTIONAL_REPORT_START_TIME", "DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "INBOUND_CALL_HISTORY_REPORT_PRC",
//									",SOURCE=SCHEDULER,CALL_TYPE=Transactional", inboundTranReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for the call type INBOUND_CALL_HISTORY_REPORT_PRC => Transactional. "
//									+ e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//						// int chatReportRC = getRunnableIntervalCount(mssqlcon,
//						// "CHAT_REPORT_START_TIME", "DATA_DUMP_START_TIME");
//						// try{
//						// ReportGenerator.prepareReport(mssqlcon, "CHAT_REPORT_PRC",
//						// ",SOURCE=SCHEDULER", chatReportRC);
//						// } catch (Exception e) {
//						// System.out.println(currenttimestamp()+"Exception occured while preparing
//						// Report for CHAT_REPORT_PRC. " + e);
//						// e.printStackTrace();
//						// //throw new Exception();
//						// }
//						int adReportRC = getRunnableIntervalCount(mssqlcon, "AGENT_DETAIL_REPORT_START_TIME",
//								"DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "AGENT_DETAIL_REPORT_PRC", ",SOURCE=SCHEDULER",
//									adReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for AGENT_DETAIL_REPORT_PRC. " + e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//						int rcReportRC = getRunnableIntervalCount(mssqlcon, "REPEATED_CALLER_REPORT_START_TIME",
//								"DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "REPEATED_CALLER_REPORT_PRC", ",SOURCE=SCHEDULER",
//									rcReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for REPEATED_CALLER_REPORT_PRC. " + e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//						int ivrchiReportRC = getRunnableIntervalCount(mssqlcon, "IVR_CALL_HISTORY_INFORMATIONAL",
//								"DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "IVR_CALL_HISTORY_REPORT_PRC",
//									",SOURCE=SCHEDULER,CALL_TYPE=INFORMATIONAL", ivrchiReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for the call type IVR_CALL_HISTORY_REPORT_PRC => Informational. "
//									+ e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//						int ivrchtReportRC = getRunnableIntervalCount(mssqlcon, "IVR_CALL_HISTORY_TRANSACTIONAL",
//								"DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "IVR_CALL_HISTORY_REPORT_PRC",
//									",SOURCE=SCHEDULER,CALL_TYPE=TRANSACTIONAL", ivrchtReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for the call type IVR_CALL_HISTORY_REPORT_PRC => Transactional. "
//									+ e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//
//						int ivroReportRC = getRunnableIntervalCount(mssqlcon, "IVR_OPERATIONAL_DETAILS_REPORT",
//								"DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "IVR_OPERATIONAL_REPORT_PRC", ",SOURCE=SCHEDULER",
//									ivroReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for the call type IVR_OPERATIONAL_REPORT_PRC. "
//									+ e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//						int ivrmpdReportRC = getRunnableIntervalCount(mssqlcon, "IVR_MENU_PATH_DETAILS_REPORT",
//								"DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "IVR_MENU_PATH_DETAILS_REPORT_PRC",
//									",SOURCE=SCHEDULER", ivrmpdReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for the call type IVR_MENU_PATH_DETAILS_REPORT_PRC. "
//									+ e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//						int allrReportRC = getRunnableIntervalCount(mssqlcon, "AGENT_LOGIN_LOGOUT_REPORT",
//								"DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "AGENT_LOGIN_LOGOUT_REPORT_PRC",
//									",SOURCE=SCHEDULER", allrReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for the call type AGENT_LOGIN_LOGOUT_REPORT_PRC. "
//									+ e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//						int cdrReportRC = getRunnableIntervalCount(mssqlcon, "CALL_DETAILS_REPORT",
//								"DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "CALL_DETAILS_REPORT_PRC", ",SOURCE=SCHEDULER",
//									cdrReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for the call type CALL_DETAILS_REPORT_PRC. "
//									+ e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//						int sgReportRC = getRunnableIntervalCount(mssqlcon, "SERVICE_GROUP_REPORT_START_TIME",
//								"DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "SERVICE_GROUP_REPORT_PRC", ",SOURCE=SCHEDULER",
//									sgReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for SERVICE_GROUP_REPORT_PRC. " + e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//						int emailReportRC = getRunnableIntervalCount(mssqlcon, "EMAIL_REPORT_START_TIME",
//								"DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReportStatementExecute(mssqlcon, "EMAIL_REPORT_PRC",
//									",SOURCE=SCHEDULER", emailReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for EMAIL_REPORT_PRC. " + e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
//						int sReportRC = getRunnableIntervalCount(mssqlcon, "STAFF_REPORT_START_TIME",
//								"DATA_DUMP_START_TIME");
//						try {
//							ReportGenerator.prepareReport(mssqlcon, "STAFF_REPORT_PRC", ",SOURCE=SCHEDULER", sReportRC);
//						} catch (Exception e) {
//							System.out.println(currenttimestamp()
//									+ "Exception occured while preparing Report for STAFF_REPORT_PRC. " + e);
//							e.printStackTrace();
//							// throw new Exception();
//						}
						
						

						// 2b.Report added for KM_REPORT_PRC,CALL_BACK_ASSIST_REPORT_PRC,
						// CUSTOMER_JOURNEY_REPORT_PRC,
						// CDR_EXTRACT_PRC, SEGMENT_EXTRACT_PRC, MAX_AHT_PRC, MAX_WAIT_ABANDONED_PRC,
						// MAX_WAIT_ANSWERED_PRC, POM_PRC

						int kmReportRC = getRunnableIntervalCount(mssqlcon, "KM_REPORT_START_TIME",
								"DATA_DUMP_START_TIME");
						try {
							ReportGenerator.prepareReport(mssqlcon, "KM_REPORT_PRC", ",SOURCE=SCHEDULER", kmReportRC);
						} catch (Exception e) {
							System.out.println(currenttimestamp()
									+ "Exception occured while preparing Report for the call type KM_REPORT_PRC. " + e);
							e.printStackTrace();
							// throw new Exception();
						}

						int callBackAssistReportRC = getRunnableIntervalCount(mssqlcon,
								"CALL_BACK_ASSIST_REPORT_START_TIME", "DATA_DUMP_START_TIME");
						try {
							ReportGenerator.prepareReport(mssqlcon, "CALL_BACK_ASSIST_REPORT_PRC", ",SOURCE=SCHEDULER",
									callBackAssistReportRC);
						} catch (Exception e) {
							System.out.println(currenttimestamp()
									+ "Exception occured while preparing Report for the call type CALL_BACK_ASSIST_REPORT_PRC. "
									+ e);
							e.printStackTrace();
							// throw new Exception();
						}

						int customerJourneyReportRC = getRunnableIntervalCount(mssqlcon,
								"CUSTOMER_JOURNEY_REPORT_START_TIME", "DATA_DUMP_START_TIME");
						try {
							ReportGenerator.prepareReport(mssqlcon, "CUSTOMER_JOURNEY_REPORT_PRC", ",SOURCE=SCHEDULER",
									customerJourneyReportRC);
						} catch (Exception e) {
							System.out.println(currenttimestamp()
									+ "Exception occured while preparing Report for the call type CUSTOMER_JOURNEY_REPORT_PRC. "
									+ e);
							e.printStackTrace();
							// throw new Exception();
						}

						int cdrExtractRC = getRunnableIntervalCount(mssqlcon, "CDR_EXTRACT_START_TIME",
								"DATA_DUMP_START_TIME");
						try {
							ReportGenerator.prepareReport(mssqlcon, "CDR_EXTRACT_PRC", ",SOURCE=SCHEDULER",
									cdrExtractRC);
						} catch (Exception e) {
							System.out.println(currenttimestamp()
									+ "Exception occured while preparing Report for the call type CDR_EXTRACT_PRC. "
									+ e);
							e.printStackTrace();
							// throw new Exception();
						}

						int segmentExtractRC = getRunnableIntervalCount(mssqlcon, "SEGMENT_EXTRACT_START_TIME",
								"DATA_DUMP_START_TIME");
						try {
							ReportGenerator.prepareReport(mssqlcon, "SEGMENT_EXTRACT_PRC", ",SOURCE=SCHEDULER",
									segmentExtractRC);
						} catch (Exception e) {
							System.out.println(currenttimestamp()
									+ "Exception occured while preparing Report for the call type SEGMENT_EXTRACT_PRC. "
									+ e);
							e.printStackTrace();
							// throw new Exception();
						}

						int maxAhtRC = getRunnableIntervalCount(mssqlcon, "MAX_AHT_START_TIME", "DATA_DUMP_START_TIME");
						try {
							ReportGenerator.prepareReport(mssqlcon, "MAX_AHT_PRC", ",SOURCE=SCHEDULER", maxAhtRC);
						} catch (Exception e) {
							System.out.println(currenttimestamp()
									+ "Exception occured while preparing Report for the call type MAX_AHT_PRC. " + e);
							e.printStackTrace();
							// throw new Exception();
						}

						int maxWaitAbandonedRC = getRunnableIntervalCount(mssqlcon, "MAX_WAIT_ABANDONED_START_TIME",
								"DATA_DUMP_START_TIME");
						try {
							ReportGenerator.prepareReport(mssqlcon, "MAX_WAIT_ABANDONED_PRC", ",SOURCE=SCHEDULER",
									maxWaitAbandonedRC);
						} catch (Exception e) {
							System.out.println(currenttimestamp()
									+ "Exception occured while preparing Report for the call type MAX_WAIT_ABANDONED_PRC. "
									+ e);
							e.printStackTrace();
							// throw new Exception();
						}

						int maxWaitAnsweredRC = getRunnableIntervalCount(mssqlcon, "MAX_WAIT_ANSWERED_START_TIME",
								"DATA_DUMP_START_TIME");
						try {
							ReportGenerator.prepareReport(mssqlcon, "MAX_WAIT_ANSWERED_PRC", ",SOURCE=SCHEDULER",
									maxWaitAnsweredRC);
						} catch (Exception e) {
							System.out.println(currenttimestamp()
									+ "Exception occured while preparing Report for the call type MAX_WAIT_ANSWERED_PRC. "
									+ e);
							e.printStackTrace();
							// throw new Exception();
						}

						int pomRC = getRunnableIntervalCount(mssqlcon, "POM_START_TIME", "DATA_DUMP_START_TIME");
						try {
							ReportGenerator.prepareReport(mssqlcon, "POM_PRC", ",SOURCE=SCHEDULER", pomRC);
						} catch (Exception e) {
							System.out.println(currenttimestamp()
									+ "Exception occured while preparing Report for the call type POM_PRC. " + e);
							e.printStackTrace();
							// throw new Exception();
						}

						System.out.println(currenttimestamp() + "All the Reporting Procedure executed");
						System.out.println(currenttimestamp() + "Do nothing for 1000 miliseconds (1 second).....");
						Thread.sleep(1000); // do nothing for 1000 miliseconds (1 second)

					} else {
						System.out.println(currenttimestamp() + "Data load is not completed for the period: "
								+ START_TIME + " - " + END_TIME);
					}
					System.out.println(currenttimestamp() + "********* Interval Ended ********* " + i);
				}
				// runnableInterval = getRunnableIntervalCount(mssqlcon, "DATA_DUMP_START_TIME",
				// "DATA_DUMP_START_TIME");
				// run(con, mssqlcon, runnableInterval);
			} else {
				System.out.println(currenttimestamp() + "Total Runnable Interval is less than 1 : " + runnableInterval);
			}
		} catch (Exception e) {

		}
	}

	public static Integer getRunnableIntervalCount(Connection con, String startTimeName, String endTimeName)
			throws Exception {
		Integer runnableInterval = 0;
		Statement stmt = con.createStatement();
		String sql = "";
		ResultSet rs = null;
		String startTime = "";
		String endTime = "";
		long bufferMinutes = 0;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		if (startTimeName.equalsIgnoreCase("DATA_DUMP_START_TIME")) {
			// sql = "SELECT CONVERT(VARCHAR(50), CONVERT(DATETIME, PARAM_VALUE, 121), 121)
			// AS START_TIME FROM CONFIG_PARAMS WHERE PARAM_NAME = '"+startTimeName+"'";
			// System.out.println(currenttimestamp()+"getRunnableIntervalCount =>
			// startTimeName : " + startTimeName + " => paramName => " + endTimeName + ".
			// Query: " + sql);
			// rs = stmt.executeQuery(sql);
			// while(rs.next()) {
			// startTime = rs.getString(1);
			// }
			// Date ct = new Date();
			// endTime = sdf.format(ct);

			sql = "SELECT CONVERT(VARCHAR(50), CONVERT(DATETIME, PARAM_VALUE, 121), 121) AS START_TIME, (SELECT CONVERT(VARCHAR(50), CONVERT(DATETIME, CURRENT_TIMESTAMP, 121), 121) AS END_TIME FROM CONFIG_PARAMS WHERE PARAM_NAME = '"
					+ endTimeName + "') as END_TIME FROM CONFIG_PARAMS WHERE PARAM_NAME = '" + startTimeName + "'";
			System.out.println(currenttimestamp() + "getRunnableIntervalCount => startTimeName : " + startTimeName
					+ " => endTimeName => " + endTimeName + ". Query: " + sql);
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				startTime = rs.getString(1);
				endTime = rs.getString(2);
			}
			bufferMinutes = 60;
		} else {
			sql = "SELECT CONVERT(VARCHAR(50), CONVERT(DATETIME, PARAM_VALUE, 121), 121) AS START_TIME, (SELECT CONVERT(VARCHAR(50), CONVERT(DATETIME, PARAM_VALUE, 121), 121) AS END_TIME FROM CONFIG_PARAMS WHERE PARAM_NAME = '"
					+ endTimeName + "') as end_time FROM CONFIG_PARAMS WHERE PARAM_NAME = '" + startTimeName + "'";
			System.out.println(currenttimestamp() + "getRunnableIntervalCount => startTimeName : " + startTimeName
					+ " => endTimeName => " + endTimeName + ". Query: " + sql);
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				startTime = rs.getString(1);
				endTime = rs.getString(2);
			}
			bufferMinutes = 0;
		}
		Date st = sdf.parse(startTime);
		Date et = sdf.parse(endTime);
		System.out.println(currenttimestamp() + "Start Time : " + sdf.format(st) + " & End Time : " + sdf.format(et));
		System.out.println(currenttimestamp() + "Total Minutes Difference : "
				+ (((et.getTime() - st.getTime()) / 1000) / 60) + " & Buffer Minutes : " + bufferMinutes);
		long totalRunnableInterval = (((((et.getTime() - st.getTime()) / 1000) / 60) - bufferMinutes) / 30);
		runnableInterval = (int) totalRunnableInterval;
		System.out.println(currenttimestamp() + "Total Runnable Interval : " + runnableInterval);
		rs.close();
		return runnableInterval;
	}

	public static void main(String args[]) throws Exception {

		System.out.println("\n" + currenttimestamp() + "********* STARTED@ ********* ");

		try {
			FileInputStream fis = new FileInputStream("E:\\RTA\\SampleApplication\\config\\TestconfigCBA.properties");
			Properties prop = new Properties();
			prop.load(fis);

			String db_name = "db.postgresql";
			String driver = prop.getProperty(db_name + ".driver");
			String url = prop.getProperty(db_name + ".connection.url");
			String user = prop.getProperty(db_name + ".user");
			String password = prop.getProperty(db_name + ".password");

			// System.out.println("Driver:" + driver + ", url:" + url + ", user:" + user +
			// ", password:" + password);
			Class.forName(driver);
			password = EncryptionAndDecryption.decrypt(password, "CustomReporting");
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println(currenttimestamp() + "Connection created successfully for the DB : " + db_name);

			db_name = "db.mssql";
			driver = prop.getProperty(db_name + ".driver");
			url = prop.getProperty(db_name + ".connection.url");
			user = prop.getProperty(db_name + ".user");
			password = prop.getProperty(db_name + ".password");

			// System.out.println("Driver:" + driver + ", url:" + url + ", user:" + user +
			// ", password:" + password);
			Class.forName(driver);
			password = EncryptionAndDecryption.decrypt(password, "CustomReporting");
			Connection mssqlcon = DriverManager.getConnection(url, user, password);
			System.out.println(currenttimestamp() + "Connection created successfully for the DB : " + db_name);

			// 2b.CBA postgresql data base connection configuration
			db_name = "db.postgresql.cba";
			driver = prop.getProperty(db_name + ".driver");
			url = prop.getProperty(db_name + ".connection.url");
			user = prop.getProperty(db_name + ".user");
			password = prop.getProperty(db_name + ".password");
			System.out.println(currenttimestamp()+" CBA Postgres Connection creation Entry ");

			// System.out.println("Driver:" + driver + ", url:" + url + ", user:" + user +
			// ", password:" + password);
			Class.forName(driver);
			password = EncryptionAndDecryption.decrypt(password, "CustomReporting");
			Connection cbacon = DriverManager.getConnection(url, user, password);
			System.out.println(currenttimestamp()+" CBA Postgres Connection created successfully for the DB : " + db_name);
			System.out.println(currenttimestamp()+" CBA Postgres Connection creation Exit ");

			// db_name = "db.alltrunk.postgresql";
			// driver = prop.getProperty(db_name + ".driver");
			// url = prop.getProperty(db_name + ".connection.url");
			// user = prop.getProperty(db_name + ".user");
			// password = prop.getProperty(db_name + ".password");
			// password = EncryptionAndDecryption.decrypt(password,"CustomReporting");
			// System.out.println(db_name + ".driver : " + driver +", "+db_name +
			// ".connection.url : " + url + ","+db_name + ".user : " + user + ","+db_name +
			// ".password : " + password);
			// Class.forName(driver);
			// Connection alltrunckcon=DriverManager.getConnection(url, user, password);
			// System.out.println("Connection created successfully for the DB: " + db_name);

			// IVR_MENU_SUMMARY_REPORT_PRC
			String string1 = "02:00:00";
			Date time1 = new SimpleDateFormat("HH:mm:ss").parse(string1);
			Calendar calendar1 = Calendar.getInstance();
			calendar1.setTime(time1);
			calendar1.add(Calendar.DATE, 1);

			String string2 = "02:30:00";
			Date time2 = new SimpleDateFormat("HH:mm:ss").parse(string2);
			Calendar calendar2 = Calendar.getInstance();
			calendar2.setTime(time2);
			calendar2.add(Calendar.DATE, 1);

			Date date = new Date();
			String strDateFormat = "HH:mm:ss";
			DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
			String formattedDate = dateFormat.format(date);
			Calendar current_calendar = Calendar.getInstance();
			current_calendar.setTime(new SimpleDateFormat("HH:mm:ss").parse(formattedDate));
			current_calendar.add(Calendar.DATE, 1);

			Date x = current_calendar.getTime();
			System.out.println(currenttimestamp()
					+ "IVR_MENU_SUMMARY_REPORT_PRC only will be excuted between 02:00:00 AM and 02:30:00 AM");
			System.out.println(currenttimestamp() + "Current Time : " + formattedDate);
			// checks whether the current time is between 02:00:00 and 02:30:00.
			if (x.after(calendar1.getTime()) && x.before(calendar2.getTime())) {
				// System.out.println(true);
				try {
					ReportGenerator.prepareReportStatementExecute(mssqlcon, "IVR_MENU_SUMMARY_REPORT_PRC",
							",SOURCE=SCHEDULER");
				} catch (Exception e) {
					System.out.println(currenttimestamp()
							+ "Exception occured while preparing Report for IVR_MENU_SUMMARY_REPORT_PRC. "
							+ e.getMessage());
					e.printStackTrace();
					// throw new Exception();
				}
			} else {
				System.out.println(currenttimestamp() + " Current time is not between 02:00:00 AM and 02:30:00 AM ");
			}

			int runnableInterval = 0;
			runnableInterval = getRunnableIntervalCount(mssqlcon, "DATA_DUMP_START_TIME", "DATA_DUMP_START_TIME");
			// 2b.run method call with cbacon
			// ***********************************************************
			run(con, cbacon, mssqlcon, runnableInterval);

			// 2b.CBA postgresql data base connection close
			// *************************************************
			System.out.println(currenttimestamp() + "Connection Closed successfully for the DB : db.postgresql.cba");
			cbacon.close();

			System.out.println(currenttimestamp() + "Connection Closed successfully for the DB : db.postgresql");
			con.close();
			System.out.println(currenttimestamp() + "Connection Closed successfully for the DB : db.mssql");
			mssqlcon.close();
		} catch (Exception e) {
			// System.out.println(currenttimestamp()+ e);
			System.out.println(currenttimestamp() + "Exception occurred while connecting to DB. " + e);
			e.printStackTrace();
		}
		System.out.println(currenttimestamp() + "********* END@ *********  ");

	}
}
