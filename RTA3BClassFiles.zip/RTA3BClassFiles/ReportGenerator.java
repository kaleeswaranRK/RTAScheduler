

//javac -classpath E:\CustomReporting\scheduler\libs\mssql-jdbc-8.4.1.jre8.jar;E:\CustomReporting\scheduler\libs\postgresql-42.2.18.jar;. ReportGenerator.java
//java -classpath E:\CustomReporting\scheduler\libs\mssql-jdbc-8.4.1.jre8.jar;E:\CustomReporting\scheduler\libs\postgresql-42.2.18.jar;. ReportGenerator

import java.io.FileInputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;

public class ReportGenerator {
  public static void prepareReport(Connection paramConnection, String paramString1, String paramString2) throws Exception {
    String str1 = "";
    String str2 = "";
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(new Date());
    String str3 = "PARAM_NAME=" + paramString1 + ",START_TIME=" + str1 + ",END_TIME=" + str2 + paramString2;
    System.out.println(new Timestamp((new Date()).getTime()) + " : Proc_name : " + paramString1 + " & param_name : " + str3);
    String str4 = "{call " + paramString1 + "(?,?)}";
    CallableStatement callableStatement = paramConnection.prepareCall(str4);
    callableStatement.setString(1, str3);
    callableStatement.registerOutParameter(2, 12);
    callableStatement.executeUpdate();
    String str5 = callableStatement.getString(2);
    System.out.println(new Timestamp((new Date()).getTime()) + " : Status : " + str5);
  }
  
  public static void prepareReport(Connection paramConnection, String paramString1, String paramString2, int paramInt) throws Exception {
    String str1 = "";
    String str2 = "";
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(new Date());
    String str3 = "PARAM_NAME=" + paramString1 + ",START_TIME=" + str1 + ",END_TIME=" + str2 + paramString2;
    System.out.println(new Timestamp((new Date()).getTime()) + " : Proc_name : " + paramString1 + " & param_name : " + str3 + " & runnableCount : " + paramInt);
//    for (byte b = 0; b < paramInt; b++) {
//      String str4 = "{call " + paramString1 + "(?,?)}";
//      CallableStatement callableStatement = paramConnection.prepareCall(str4);
//      callableStatement.setString(1, str3);
//      callableStatement.registerOutParameter(2, 12);
//      callableStatement.executeUpdate();
//      String str5 = callableStatement.getString(2);
//      System.out.println(new Timestamp((new Date()).getTime()) + " : " + b + " Status : " + str5);
//    } 
  }
  
  public static void prepareReportWithoutParamater(Connection paramConnection, String paramString1, String paramString2) throws Exception {
    String str1 = "";
    String str2 = "";
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(new Date());
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String str3 = "PARAM_NAME=" + paramString1 + ",START_TIME=" + str1 + ",END_TIME=" + str2 + paramString2;
    simpleDateFormat.setTimeZone(TimeZone.getDefault());
    System.out.println("\n\n ********* STARTED@ ********* " + simpleDateFormat.format(calendar.getTime()));
    System.out.println("Proc_name: " + paramString1 + ", param_name: " + str3);
    String str4 = "{call " + paramString1 + "(?)}";
    CallableStatement callableStatement = paramConnection.prepareCall(str4);
    callableStatement.registerOutParameter(1, 12);
    callableStatement.executeUpdate();
    String str5 = callableStatement.getString(1);
    System.out.println("Status: " + str5);
    calendar.setTime(new Date());
    System.out.println("********* END@ *********  " + simpleDateFormat.format(calendar.getTime()));
  }
  
  public static void prepareReportStatementExecute(Connection paramConnection, String paramString1, String paramString2) throws Exception {
    String str1 = "";
    String str2 = "";
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(new Date());
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String str3 = "PARAM_NAME=" + paramString1 + ",START_TIME=" + str1 + ",END_TIME=" + str2 + paramString2;
    simpleDateFormat.setTimeZone(TimeZone.getDefault());
    System.out.println(new Timestamp((new Date()).getTime()) + " : Proc_name: " + paramString1 + ", param_name: " + str3);
    String str4 = "{call " + paramString1 + "(?,?)}";
    CallableStatement callableStatement = paramConnection.prepareCall(str4);
    callableStatement.setString(1, str3);
    callableStatement.registerOutParameter(2, 12);
    callableStatement.execute();
    String str5 = callableStatement.getString(2);
    System.out.println(new Timestamp((new Date()).getTime()) + " : Status: " + str5);
    calendar.setTime(new Date());
  }
  
  public static void prepareReportStatementExecute(Connection paramConnection, String paramString1, String paramString2, int paramInt) throws Exception {
    String str1 = "";
    String str2 = "";
    String str3 = "PARAM_NAME=" + paramString1 + ",START_TIME=" + str1 + ",END_TIME=" + str2 + paramString2;
    System.out.println(new Timestamp((new Date()).getTime()) + " : Proc_name : " + paramString1 + " & param_name : " + str3 + " & runnableCount : " + paramInt);
    for (byte b = 0; b < paramInt; b++) {
      String str4 = "{call " + paramString1 + "(?,?)}";
      CallableStatement callableStatement = paramConnection.prepareCall(str4);
      callableStatement.setString(1, str3);
      callableStatement.registerOutParameter(2, 12);
      callableStatement.execute();
      String str5 = callableStatement.getString(2);
      System.out.println(new Timestamp((new Date()).getTime()) + " : " + b + " Status : " + str5);
    } 
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(new Date());
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    simpleDateFormat.setTimeZone(TimeZone.getDefault());
    System.out.println("********* STARTED@ ********* " + simpleDateFormat.format(calendar.getTime()));
    try {
      FileInputStream fileInputStream = new FileInputStream("E:/CustomReporting/scheduler/config.properties");
      Properties properties = new Properties();
      properties.load(fileInputStream);
      String str1 = "db.mssql";
      String str2 = properties.getProperty(str1 + ".driver");
      String str3 = properties.getProperty(str1 + ".connection.url");
      String str4 = properties.getProperty(str1 + ".user");
      String str5 = properties.getProperty(str1 + ".password");
      str5 = EncryptionAndDecryption.decrypt(str5, "CustomReporting");
      System.out.println("Driver:" + str2 + ", url:" + str3 + ", user:" + str4 + ", password:" + str5);
      Class.forName(str2);
      Connection connection = DriverManager.getConnection(str3, str4, str5);
      connection.close();
    } catch (Exception exception) {
      System.out.println(exception);
      System.out.println("Exception occurred while connecting to DB. " + exception);
      exception.printStackTrace();
    } 
    calendar.setTime(new Date());
    System.out.println("********* END@ *********  " + simpleDateFormat.format(calendar.getTime()));
  }
}
